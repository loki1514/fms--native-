# Autopilot Mobile - Web to Native Conversion

This is your actual Autopilot web app converted to React Native/Expo.

## 🎯 What Was Converted

### From Your Web App (Next.js)
```
app/(dashboard)/layout.tsx          →  app/(app)/_layout.tsx
app/(auth)/login/page.tsx           →  app/(auth)/login.tsx
app/(dashboard)/[orgId]/dashboard   →  app/(app)/(tabs)/dashboard.tsx
@/frontend/context/AuthContext      →  src/context/AuthContext.tsx
@/frontend/components/ui/Loader     →  src/components/ui/Loader.tsx
@/lib/supabase/client.ts            →  src/lib/supabase.ts
```

## 🚀 Quick Start

### 1. Install Dependencies
```bash
cd autopilot-rn-conversion
npm install
```

### 2. Start with Tunnel (Public URL)
```bash
npx expo start --tunnel
```

This creates a public URL that works from any device.

### 3. Run on Device
- **iOS**: Press `i` for simulator, or scan QR with Expo Go app
- **Android**: Press `a` for emulator, or scan QR with Expo Go app
- **Web**: Press `w` for web preview

## 📁 Project Structure

```
autopilot-rn-conversion/
├── app/                          # Expo Router (file-based routing)
│   ├── (auth)/                   # Auth group
│   │   ├── _layout.tsx           # Auth layout
│   │   ├── login.tsx             # Login screen (converted)
│   │   ├── register.tsx          # Register screen
│   │   └── forgot-password.tsx   # Forgot password
│   ├── (app)/                    # Main app (authenticated)
│   │   ├── _layout.tsx           # App layout (converted from dashboard layout)
│   │   └── (tabs)/               # Bottom tabs
│   │       ├── _layout.tsx       # Tab layout
│   │       ├── dashboard.tsx     # Dashboard (converted)
│   │       ├── tickets.tsx       # Tickets screen
│   │       ├── visitors.tsx      # Visitors screen
│   │       ├── inventory.tsx     # Inventory screen
│   │       └── more.tsx          # More/Settings
│   ├── _layout.tsx               # Root layout
│   └── index.tsx                 # Entry point
├── src/
│   ├── components/
│   │   ├── layout/               # Layout components
│   │   │   ├── ContextBar.tsx    # Context bar (converted)
│   │   │   └── Sidebar.tsx       # Sidebar (converted)
│   │   └── ui/
│   │       └── Loader.tsx        # Loader (converted)
│   ├── context/
│   │   └── AuthContext.tsx       # Auth context (converted)
│   ├── lib/
│   │   └── supabase.ts           # Supabase client (converted)
│   └── hooks/                    # Custom hooks
├── .env                          # Your Supabase credentials
├── app.json                      # Expo config
└── package.json                  # Dependencies
```

## 🔄 Conversion Mapping

### Components

| Web (Next.js) | Mobile (React Native) |
|--------------|----------------------|
| `<div>` | `<View>` |
| `<span>`, `<p>` | `<Text>` |
| `<button>` | `<TouchableOpacity>` |
| `<input>` | `<TextInput>` |
| `className="..."` | `style={styles...}` |
| Tailwind CSS | StyleSheet |
| `useRouter()` (next) | `useRouter()` (expo-router) |
| `useParams()` (next) | `useLocalSearchParams()` |

### File Structure

| Web Path | Mobile Path |
|----------|-------------|
| `app/(auth)/login/page.tsx` | `app/(auth)/login.tsx` |
| `app/(dashboard)/[orgId]/dashboard` | `app/(app)/(tabs)/dashboard.tsx` |
| `app/(dashboard)/[orgId]/settings` | `app/(app)/(tabs)/settings.tsx` |
| `app/org/[orgId]/page.tsx` | `app/org/[id].tsx` |
| `app/tickets/[ticketId]/page.tsx` | `app/ticket/[id].tsx` |

## 🛠️ Converting More Files

To convert additional files from your web app:

1. **Copy the web file** to the mobile project
2. **Run the converter**:
   ```bash
   node convert-web-to-mobile.js
   ```
3. **Review the converted file** and fix any issues

### Manual Conversion Steps

1. **Replace HTML elements**:
   - `<div>` → `<View>`
   - `<span>`, `<p>` → `<Text>`
   - `<button>` → `<TouchableOpacity>`
   - `<input>` → `<TextInput>`

2. **Update imports**:
   - `next/navigation` → `expo-router`
   - `@/frontend/...` → `@/src/...`

3. **Convert styles**:
   - `className="flex items-center"` → `style={{ flexDirection: 'row', alignItems: 'center' }}`

4. **Update event handlers**:
   - `onClick` → `onPress`
   - `onSubmit` → manual form handling

## 📱 Testing on Your Device

### Option 1: Expo Go App (Recommended)
1. Install "Expo Go" from App Store/Play Store
2. Run `npx expo start --tunnel`
3. Scan the QR code with your phone

### Option 2: Simulator
- iOS: Press `i` (requires macOS + Xcode)
- Android: Press `a` (requires Android Studio)

## 🔧 Troubleshooting

### "Module not found" errors
```bash
npm install
```

### "Invalid hook call"
Make sure you're using the correct imports from `expo-router` not `next/navigation`

### Styles not working
React Native uses different style properties than CSS:
- `flex-direction` → `flexDirection`
- `align-items` → `alignItems`
- `justify-content` → `justifyContent`
- `background-color` → `backgroundColor`

## 🚀 Building for Production

### iOS
```bash
eas build --platform ios
```

### Android
```bash
eas build --platform android
```

### Submit to Stores
```bash
eas submit --platform ios
eas submit --platform android
```

## 📚 Next Steps

1. ✅ Review converted files
2. ✅ Add missing screens (tickets, visitors, inventory)
3. ✅ Add navigation between screens
4. ✅ Test on physical device
5. ✅ Build and submit to App Store/Play Store

## 💬 Need Help?

The converter script (`convert-web-to-mobile.js`) shows the mapping between web and mobile components. Run it to see what changes are needed for each file.

#!/usr/bin/env node
/**
 * Autopilot Web to Mobile Converter
 * 
 * This script converts your Next.js web app components to React Native
 * Run this in your web app directory to generate mobile-compatible code
 */

const fs = require('fs');
const path = require('path');

// Conversion rules
const conversions = {
  // HTML elements to React Native components
  elements: {
    'div': 'View',
    'span': 'Text',
    'p': 'Text',
    'h1': 'Text',
    'h2': 'Text',
    'h3': 'Text',
    'button': 'TouchableOpacity',
    'input': 'TextInput',
    'img': 'Image',
    'a': 'Link',
    'form': 'View',
    'ul': 'View',
    'li': 'View',
    'nav': 'View',
    'header': 'View',
    'footer': 'View',
    'main': 'View',
    'section': 'View',
    'article': 'View',
    'aside': 'View',
  },
  
  // Import mappings
  imports: {
    'next/navigation': 'expo-router',
    'next/link': 'expo-router',
    'next/image': 'react-native',
    'react': 'react',
    '@/frontend/context/AuthContext': '@/context/AuthContext',
    '@/frontend/components': '@/components',
    '@/lib/supabase/client': '@/lib/supabase',
  },
  
  // Hook mappings
  hooks: {
    'useRouter': 'useRouter',
    'useParams': 'useLocalSearchParams',
    'usePathname': 'usePathname',
    'useSearchParams': 'useLocalSearchParams',
  },
  
  // Tailwind to StyleSheet (basic mappings)
  tailwind: {
    'flex': '{ flex: 1 }',
    'flex-row': '{ flexDirection: "row" }',
    'flex-col': '{ flexDirection: "column" }',
    'items-center': '{ alignItems: "center" }',
    'justify-center': '{ justifyContent: "center" }',
    'justify-between': '{ justifyContent: "space-between" }',
    'p-4': '{ padding: 16 }',
    'px-4': '{ paddingHorizontal: 16 }',
    'py-4': '{ paddingVertical: 16 }',
    'm-4': '{ margin: 16 }',
    'mx-4': '{ marginHorizontal: 16 }',
    'my-4': '{ marginVertical: 16 }',
    'bg-white': '{ backgroundColor: "#fff" }',
    'bg-gray-100': '{ backgroundColor: "#f3f4f6" }',
    'text-center': '{ textAlign: "center" }',
    'font-bold': '{ fontWeight: "bold" }',
    'rounded-lg': '{ borderRadius: 8 }',
    'shadow': '{ shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 }',
    'hidden': '{ display: "none" }',
    'block': '{ display: "flex" }',
    'w-full': '{ width: "100%" }',
    'h-full': '{ height: "100%" }',
    'min-h-screen': '{ flex: 1 }',
    'overflow-hidden': '{ overflow: "hidden" }',
    'overflow-y-auto': '{ overflow: "scroll" }',
    'border': '{ borderWidth: 1, borderColor: "#e5e7eb" }',
    'border-b': '{ borderBottomWidth: 1, borderBottomColor: "#e5e7eb" }',
    'space-x-2': 'gap: 8 (use gap in parent)',
    'space-y-2': 'gap: 8 (use gap in parent)',
    'gap-4': '{ gap: 16 }',
    'relative': '{ position: "relative" }',
    'absolute': '{ position: "absolute" }',
    'fixed': '{ position: "absolute" }',
    'z-10': '{ zIndex: 10 }',
    'top-0': '{ top: 0 }',
    'left-0': '{ left: 0 }',
    'right-0': '{ right: 0 }',
    'bottom-0': '{ bottom: 0 }',
  }
};

// Function to convert a single file
function convertFile(inputPath, outputPath) {
  let content = fs.readFileSync(inputPath, 'utf8');
  
  console.log(`Converting: ${inputPath}`);
  
  // Track changes
  const changes = [];
  
  // 1. Convert imports
  for (const [web, mobile] of Object.entries(conversions.imports)) {
    const regex = new RegExp(`from ['"]${web}['"]`, 'g');
    if (regex.test(content)) {
      content = content.replace(regex, `from '${mobile}'`);
      changes.push(`Import: ${web} → ${mobile}`);
    }
  }
  
  // 2. Convert hooks
  for (const [web, mobile] of Object.entries(conversions.hooks)) {
    // Check if imported from next/navigation
    if (content.includes('next/navigation') && content.includes(web)) {
      changes.push(`Hook: ${web} → ${mobile} (from expo-router)`);
    }
  }
  
  // 3. Convert HTML elements to React Native components
  for (const [html, rn] of Object.entries(conversions.elements)) {
    // Match JSX tags (opening, closing, self-closing)
    const openTag = new RegExp(`<${html}([^>]*)>`, 'g');
    const closeTag = new RegExp(`</${html}>`, 'g');
    const selfCloseTag = new RegExp(`<${html}([^>]*)/>`, 'g');
    
    if (openTag.test(content) || selfCloseTag.test(content)) {
      content = content.replace(openTag, `<${rn}$1>`);
      content = content.replace(closeTag, `</${rn}>`);
      content = content.replace(selfCloseTag, `<${rn}$1/>`);
      changes.push(`Element: <${html}> → <${rn}>`);
    }
  }
  
  // 4. Convert className to style (basic detection)
  const classNameRegex = /className=["']([^"']+)["']/g;
  let match;
  while ((match = classNameRegex.exec(content)) !== null) {
    const classes = match[1].split(' ');
    const styles = classes.map(c => conversions.tailwind[c] || `/* TODO: ${c} */`).filter(Boolean);
    if (styles.length > 0) {
      changes.push(`Style: className="${match[1]}" → style={[${styles.join(', ')}]}`);
    }
  }
  
  // 5. Add React Native imports if needed
  const needsRN = Object.values(conversions.elements).some(el => 
    content.includes(`<${el}`) || content.includes(`</${el}>`)
  );
  
  if (needsRN && !content.includes('from \'react-native\'')) {
    const rnImports = Object.values(conversions.elements)
      .filter((v, i, a) => a.indexOf(v) === i)
      .filter(el => content.includes(`<${el}`) || content.includes(`</${el}>`))
      .join(', ');
    
    if (rnImports) {
      content = `import { ${rnImports} } from 'react-native';\n` + content;
      changes.push(`Added import: { ${rnImports} } from 'react-native'`);
    }
  }
  
  // 6. Convert onClick to onPress
  if (content.includes('onClick=')) {
    content = content.replace(/onClick=/g, 'onPress=');
    changes.push('Event: onClick → onPress');
  }
  
  // 7. Convert img src to Image source
  const imgRegex = /<Image[^>]*src=["']([^"']+)["'][^>]*\/>/g;
  if (imgRegex.test(content)) {
    content = content.replace(imgRegex, (match, src) => {
      return match.replace(`src="${src}"`, `source={{ uri: '${src}' }}`);
    });
    changes.push('Image: src → source={{ uri: ... }}');
  }
  
  // Write output
  fs.writeFileSync(outputPath, content);
  
  return changes;
}

// Main conversion function
function convertProject(webDir, outputDir) {
  console.log('='.repeat(60));
  console.log('Autopilot Web → Mobile Converter');
  console.log('='.repeat(60));
  console.log(`\nInput: ${webDir}`);
  console.log(`Output: ${outputDir}\n`);
  
  // Create output directory
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  // Define conversion paths
  const paths = [
    { from: 'app/(auth)/login/page.tsx', to: 'app/(auth)/login.tsx' },
    { from: 'app/(auth)/register/page.tsx', to: 'app/(auth)/register.tsx' },
    { from: 'app/(auth)/forgot-password/page.tsx', to: 'app/(auth)/forgot-password.tsx' },
    { from: 'app/(dashboard)/[orgId]/dashboard/page.tsx', to: 'app/(app)/(tabs)/dashboard.tsx' },
    { from: 'app/(dashboard)/[orgId]/settings/page.tsx', to: 'app/(app)/(tabs)/settings.tsx' },
    { from: 'app/(dashboard)/[orgId]/users/page.tsx', to: 'app/(app)/(tabs)/users.tsx' },
    { from: 'app/(dashboard)/[orgId]/rooms/page.tsx', to: 'app/(app)/(tabs)/rooms.tsx' },
    { from: 'app/(dashboard)/[orgId]/flow-map/page.tsx', to: 'app/(app)/flow-map.tsx' },
    { from: 'frontend/context/AuthContext.tsx', to: 'src/context/AuthContext.tsx' },
    { from: 'frontend/components/ui/Loader.tsx', to: 'src/components/ui/Loader.tsx' },
    { from: 'lib/supabase/client.ts', to: 'src/lib/supabase.ts' },
  ];
  
  const allChanges = {};
  
  for (const { from, to } of paths) {
    const inputPath = path.join(webDir, from);
    const outputPath = path.join(outputDir, to);
    
    if (fs.existsSync(inputPath)) {
      // Create output directory
      const outputDirPath = path.dirname(outputPath);
      if (!fs.existsSync(outputDirPath)) {
        fs.mkdirSync(outputDirPath, { recursive: true });
      }
      
      const changes = convertFile(inputPath, outputPath);
      allChanges[to] = changes;
    } else {
      console.log(`⚠️  Not found: ${from}`);
    }
  }
  
  // Generate report
  console.log('\n' + '='.repeat(60));
  console.log('Conversion Report');
  console.log('='.repeat(60));
  
  for (const [file, changes] of Object.entries(allChanges)) {
    console.log(`\n📄 ${file}`);
    changes.forEach(c => console.log(`   ✓ ${c}`));
  }
  
  // Write conversion notes
  const notes = `
# Conversion Notes

## Files Converted
${Object.keys(allChanges).map(f => `- ${f}`).join('\n')}

## Manual Steps Required

1. **Install Dependencies**
   \`\`\`bash
   cd ${outputDir}
   npm install expo react-native @tamagui/core @tamagui/config
   \`\`\`

2. **Add Navigation Setup**
   - Install expo-router: \`npx expo install expo-router\`
   - Create app/_layout.tsx for root layout
   - Configure navigation structure

3. **Convert Tailwind Classes**
   - Review all className usages
   - Convert to StyleSheet or Tamagui
   - Use the tailwind mapping in convert-web-to-mobile.js

4. **Update Image Handling**
   - Web: \`<img src="..." />\`
   - Mobile: \`<Image source={{ uri: '...' }} style={{ width, height }} />\`

5. **Update Forms**
   - Web: \`<form onSubmit={...}>\`
   - Mobile: \`<View>\` with manual submission handling

6. **Test on Device**
   - Run: \`npx expo start\`
   - Test all screens
   - Fix any platform-specific issues

## Common Issues

### Issue: "window is not defined"
**Solution:** Use Platform.OS checks or move to useEffect

### Issue: "document is not defined"
**Solution:** Replace with React Native equivalents

### Issue: CSS not working
**Solution:** Use StyleSheet or Tamagui instead of Tailwind

### Issue: Images not loading
**Solution:** Use require() for local images, {uri: ...} for remote

## Next Steps

1. Review converted files
2. Fix any TODO comments
3. Add missing imports
4. Test navigation flow
5. Add platform-specific adjustments
`;
  
  fs.writeFileSync(path.join(outputDir, 'CONVERSION_NOTES.md'), notes);
  console.log('\n✅ Conversion complete!');
  console.log(`📁 Output: ${outputDir}`);
  console.log('📖 Read CONVERSION_NOTES.md for next steps');
}

// Run if called directly
if (require.main === module) {
  const webDir = process.argv[2] || '.';
  const outputDir = process.argv[3] || './mobile-output';
  
  convertProject(webDir, outputDir);
}

module.exports = { convertFile, convertProject, conversions };

// Auth layout - redirects to app if authenticated
import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { useAuth } from '@/src/context/AuthContext';
import { useRouter } from 'expo-router';

export default function AuthLayout() {
  const { user, isLoading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading && user) {
      router.replace('/(app)/(tabs)/dashboard');
    }
  }, [user, isLoading, router]);

  return (
    <Stack
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="login" />
      <Stack.Screen name="register" />
      <Stack.Screen name="forgot-password" />
    </Stack>
  );
}

// CONVERTED from: app/(dashboard)/layout.tsx
'use client';

import { useAuth } from "@/src/context/AuthContext";
import { useRouter, usePathname } from "expo-router";
import { useEffect, useState } from "react";
import { View, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { ContextBar } from "@/src/components/layout/ContextBar";
import { Sidebar, MobileHeader } from "@/src/components/layout/Sidebar";
import { Loader } from "@/src/components/ui/Loader";

export default function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !user) {
      router.replace('/(auth)/login');
    }
  }, [user, isLoading, router]);

  // Close mobile sidebar on route change
  useEffect(() => {
    setIsMobileSidebarOpen(false);
  }, [pathname]);

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <Loader size="lg" text="Initializing..." />
      </View>
    );
  }

  if (!user) {
    return null;
  }

  // Check if we're on the full dashboard page
  const isFullDashboard = pathname?.endsWith('/dashboard');

  if (isFullDashboard) {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar style="auto" />
        {children}
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="auto" />
      <View style={styles.layout}>
        {/* Mobile Header */}
        <MobileHeader onMenuToggle={() => setIsMobileSidebarOpen(true)} />

        {/* Sidebar */}
        <Sidebar
          isMobileOpen={isMobileSidebarOpen}
          onMobileClose={() => setIsMobileSidebarOpen(false)}
        />

        {/* Main Content */}
        <View style={styles.mainContent}>
          {/* Context Bar - Hidden on mobile */}
          <View style={styles.contextBarContainer}>
            <ContextBar />
          </View>
          
          <View style={styles.content}>
            {children}
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fafbfc',
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fafbfc',
  },
  layout: {
    flex: 1,
    flexDirection: 'row',
  },
  mainContent: {
    flex: 1,
    flexDirection: 'column',
    borderLeftWidth: 1,
    borderLeftColor: '#cbd5e1',
    backgroundColor: '#fff',
  },
  contextBarContainer: {
    // Hidden on mobile, shown on desktop via component logic
  },
  content: {
    flex: 1,
    padding: 16,
  },
});

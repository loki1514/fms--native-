// CONVERTED from: app/(dashboard)/[orgId]/visitors/page.tsx
'use client';

import { useState } from 'react';
import { useRouter } from 'expo-router';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  RefreshControl,
} from 'react-native';

// Mock visitor data
const mockVisitors = [
  { id: '1', name: 'John Smith', company: 'ABC Corp', status: 'checked_in', checkInTime: '10:30 AM' },
  { id: '2', name: 'Sarah Johnson', company: 'XYZ Ltd', status: 'expected', checkInTime: null },
  { id: '3', name: 'Mike Brown', company: 'Tech Inc', status: 'checked_out', checkInTime: '9:00 AM' },
];

export default function VisitorsPage() {
  const router = useRouter();
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'checked_in': return '#22c55e';
      case 'expected': return '#3b82f6';
      case 'checked_out': return '#6b7280';
      default: return '#9ca3af';
    }
  };

  const handleCheckInOut = (id: string, currentStatus: string) => {
    // Toggle status
    console.log('Toggle status for:', id);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Visitors</Text>
        <TouchableOpacity style={styles.fab} onPress={() => router.push('/(app)/visitors/new')}>
          <Text style={styles.fabText}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search visitors..."
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {/* Filter Chips */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterChips}>
        <TouchableOpacity style={[styles.chip, styles.chipActive]}>
          <Text style={styles.chipTextActive}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.chip}>
          <Text style={styles.chipText}>Checked In</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.chip}>
          <Text style={styles.chipText}>Expected</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.chip}>
          <Text style={styles.chipText}>Checked Out</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Visitors List */}
      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {mockVisitors.map((visitor) => (
          <View key={visitor.id} style={styles.visitorCard}>
            <View style={styles.visitorHeader}>
              <View>
                <Text style={styles.visitorName}>{visitor.name}</Text>
                <Text style={styles.visitorCompany}>{visitor.company}</Text>
              </View>
              <View style={[styles.statusBadge, { backgroundColor: `${getStatusColor(visitor.status)}20` }]}>
                <Text style={[styles.statusText, { color: getStatusColor(visitor.status) }]}>
                  {visitor.status.replace('_', ' ')}
                </Text>
              </View>
            </View>
            
            {visitor.status !== 'checked_out' && (
              <TouchableOpacity
                style={[
                  styles.actionButton,
                  { backgroundColor: visitor.status === 'checked_in' ? '#f59e0b' : '#22c55e' }
                ]}
                onPress={() => handleCheckInOut(visitor.id, visitor.status)}
              >
                <Text style={styles.actionButtonText}>
                  {visitor.status === 'checked_in' ? 'Check Out' : 'Check In'}
                </Text>
              </TouchableOpacity>
            )}
            
            {visitor.checkInTime && (
              <Text style={styles.timeText}>Checked in: {visitor.checkInTime}</Text>
            )}
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
  },
  fab: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: '#3b82f6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  fabText: {
    fontSize: 24,
    color: '#fff',
    fontWeight: 'bold',
  },
  searchContainer: {
    marginBottom: 12,
  },
  searchInput: {
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  filterChips: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  chip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f3f4f6',
    marginRight: 8,
  },
  chipActive: {
    backgroundColor: '#3b82f6',
  },
  chipText: {
    fontSize: 12,
    color: '#374151',
    fontWeight: '500',
  },
  chipTextActive: {
    fontSize: 12,
    color: '#fff',
    fontWeight: '500',
  },
  visitorCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  visitorHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  visitorName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  visitorCompany: {
    fontSize: 14,
    color: '#6b7280',
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
    textTransform: 'capitalize',
  },
  actionButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 8,
  },
  actionButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  timeText: {
    fontSize: 12,
    color: '#9ca3af',
  },
});

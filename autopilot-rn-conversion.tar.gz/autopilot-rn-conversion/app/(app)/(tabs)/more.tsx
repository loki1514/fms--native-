// CONVERTED from: app/(dashboard)/[orgId]/settings/page.tsx
'use client';

import { useRouter } from 'expo-router';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { useAuth } from '@/src/context/AuthContext';

interface MenuItemProps {
  title: string;
  subtitle?: string;
  icon: string;
  onPress: () => void;
  destructive?: boolean;
}

function MenuItem({ title, subtitle, icon, onPress, destructive }: MenuItemProps) {
  return (
    <TouchableOpacity style={styles.menuItem} onPress={onPress}>
      <View style={styles.menuItemContent}>
        <Text style={styles.menuIcon}>{icon}</Text>
        <View style={styles.menuText}>
          <Text style={[styles.menuTitle, destructive && styles.menuTitleDestructive]}>
            {title}
          </Text>
          {subtitle && <Text style={styles.menuSubtitle}>{subtitle}</Text>}
        </View>
      </View>
      <Text style={styles.chevron}>›</Text>
    </TouchableOpacity>
  );
}

export default function MorePage() {
  const router = useRouter();
  const { user, signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut();
    router.replace('/(auth)/login');
  };

  return (
    <ScrollView style={styles.container}>
      {/* Profile Card */}
      <View style={styles.profileCard}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            {user?.name?.[0] || user?.email?.[0] || 'U'}
          </Text>
        </View>
        <View style={styles.profileInfo}>
          <Text style={styles.profileName}>{user?.name || 'User'}</Text>
          <Text style={styles.profileEmail}>{user?.email}</Text>
          <Text style={styles.profileRole}>{user?.role?.toUpperCase()}</Text>
        </View>
        <TouchableOpacity onPress={() => router.push('/(app)/profile')}>
          <Text style={styles.chevron}>›</Text>
        </TouchableOpacity>
      </View>

      {/* Features Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>FEATURES</Text>
        <View style={styles.card}>
          <MenuItem
            title="Meeting Rooms"
            subtitle="Book and manage rooms"
            icon="📅"
            onPress={() => router.push('/(app)/rooms')}
          />
          <View style={styles.divider} />
          <MenuItem
            title="SOPs & Documents"
            subtitle="Standard operating procedures"
            icon="📄"
            onPress={() => router.push('/(app)/sops')}
          />
          <View style={styles.divider} />
          <MenuItem
            title="Properties"
            subtitle="Manage your properties"
            icon="🏢"
            onPress={() => router.push('/(app)/properties')}
          />
        </View>
      </View>

      {/* Preferences Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>PREFERENCES</Text>
        <View style={styles.card}>
          <MenuItem
            title="Notifications"
            subtitle="Manage notifications"
            icon="🔔"
            onPress={() => router.push('/(app)/notifications')}
          />
          <View style={styles.divider} />
          <MenuItem
            title="Dark Mode"
            subtitle="System default"
            icon="🌙"
            onPress={() => {/* Toggle dark mode */}}
          />
          <View style={styles.divider} />
          <MenuItem
            title="Settings"
            subtitle="App preferences"
            icon="⚙️"
            onPress={() => router.push('/(app)/settings')}
          />
        </View>
      </View>

      {/* Support Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>SUPPORT</Text>
        <View style={styles.card}>
          <MenuItem
            title="Help & Support"
            subtitle="FAQs and contact"
            icon="❓"
            onPress={() => router.push('/(app)/support')}
          />
          <View style={styles.divider} />
          <MenuItem
            title="Privacy & Security"
            subtitle="Privacy policy and terms"
            icon="🔒"
            onPress={() => router.push('/(app)/privacy')}
          />
        </View>
      </View>

      {/* Logout */}
      <View style={styles.section}>
        <View style={styles.card}>
          <MenuItem
            title="Logout"
            icon="🚪"
            onPress={handleSignOut}
            destructive
          />
        </View>
      </View>

      {/* App Version */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>Autopilot v1.0.0</Text>
        <Text style={styles.footerText}>© 2024 Autopilot Offices</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    margin: 16,
    padding: 16,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#3b82f6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  profileInfo: {
    flex: 1,
    marginLeft: 16,
  },
  profileName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111827',
  },
  profileEmail: {
    fontSize: 14,
    color: '#6b7280',
    marginTop: 2,
  },
  profileRole: {
    fontSize: 12,
    color: '#3b82f6',
    marginTop: 4,
    fontWeight: '500',
  },
  section: {
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6b7280',
    marginBottom: 8,
    marginLeft: 8,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  menuItemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  menuIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  menuText: {
    flex: 1,
  },
  menuTitle: {
    fontSize: 16,
    color: '#111827',
  },
  menuTitleDestructive: {
    color: '#dc2626',
  },
  menuSubtitle: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 2,
  },
  chevron: {
    fontSize: 20,
    color: '#9ca3af',
  },
  divider: {
    height: 1,
    backgroundColor: '#f3f4f6',
    marginLeft: 52,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  footerText: {
    fontSize: 12,
    color: '#9ca3af',
  },
});

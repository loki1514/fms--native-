// CONVERTED from: app/(dashboard)/[orgId]/inventory/page.tsx
'use client';

import { useState } from 'react';
import { useRouter } from 'expo-router';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  RefreshControl,
} from 'react-native';

// Mock inventory data
const mockItems = [
  { id: '1', name: 'Printer Paper A4', sku: 'PP-A4-001', quantity: 50, minQuantity: 20, unit: 'reams' },
  { id: '2', name: 'Coffee Beans', sku: 'CF-BN-002', quantity: 5, minQuantity: 10, unit: 'kg' },
  { id: '3', name: 'Hand Soap', sku: 'HS-LQ-003', quantity: 25, minQuantity: 15, unit: 'bottles' },
];

export default function InventoryPage() {
  const router = useRouter();
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showLowStock, setShowLowStock] = useState(false);

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  const isLowStock = (item: typeof mockItems[0]) => item.quantity <= item.minQuantity;

  const filteredItems = mockItems.filter(item => {
    if (showLowStock && !isLowStock(item)) return false;
    if (searchQuery && !item.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Inventory</Text>
        <View style={styles.headerButtons}>
          <TouchableOpacity style={styles.iconButton} onPress={() => router.push('/(app)/inventory/scan')}>
            <Text>📷</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.fab} onPress={() => router.push('/(app)/inventory/new')}>
            <Text style={styles.fabText}>+</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Search */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search items..."
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {/* Filter */}
      <TouchableOpacity
        style={[styles.filterChip, showLowStock && styles.filterChipActive]}
        onPress={() => setShowLowStock(!showLowStock)}
      >
        <Text style={[styles.filterChipText, showLowStock && styles.filterChipTextActive]}>
          ⚠️ Low Stock
        </Text>
      </TouchableOpacity>

      {/* Items List */}
      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {filteredItems.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={styles.itemCard}
            onPress={() => router.push(`/(app)/inventory/${item.id}`)}
          >
            <View style={styles.itemHeader}>
              <View style={styles.itemInfo}>
                <Text style={styles.itemName}>{item.name}</Text>
                <Text style={styles.itemSku}>SKU: {item.sku}</Text>
                <Text style={styles.itemCategory}>Unit: {item.unit}</Text>
              </View>
              {isLowStock(item) && (
                <View style={styles.lowStockBadge}>
                  <Text style={styles.lowStockText}>Low Stock</Text>
                </View>
              )}
            </View>
            
            <View style={styles.quantityRow}>
              <View style={styles.quantityContainer}>
                <View style={[
                  styles.quantityBadge,
                  { backgroundColor: isLowStock(item) ? '#fee2e2' : '#dcfce7' }
                ]}>
                  <Text style={[
                    styles.quantityText,
                    { color: isLowStock(item) ? '#dc2626' : '#16a34a' }
                  ]}>
                    {item.quantity}
                  </Text>
                </View>
                <Text style={styles.minQuantity}>/ {item.minQuantity} min</Text>
              </View>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  iconButton: {
    width: 44,
    height: 44,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  fab: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: '#3b82f6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  fabText: {
    fontSize: 24,
    color: '#fff',
    fontWeight: 'bold',
  },
  searchContainer: {
    marginBottom: 12,
  },
  searchInput: {
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  filterChip: {
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f3f4f6',
    marginBottom: 16,
  },
  filterChipActive: {
    backgroundColor: '#f59e0b',
  },
  filterChipText: {
    fontSize: 12,
    color: '#374151',
    fontWeight: '500',
  },
  filterChipTextActive: {
    color: '#fff',
  },
  itemCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  itemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  itemSku: {
    fontSize: 14,
    color: '#6b7280',
    marginTop: 2,
  },
  itemCategory: {
    fontSize: 12,
    color: '#9ca3af',
    marginTop: 2,
  },
  lowStockBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
    backgroundColor: '#fee2e2',
  },
  lowStockText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#dc2626',
  },
  quantityRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  quantityBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  quantityText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  minQuantity: {
    fontSize: 12,
    color: '#9ca3af',
  },
});

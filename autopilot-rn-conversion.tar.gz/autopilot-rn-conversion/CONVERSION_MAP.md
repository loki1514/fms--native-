# Autopilot Web → React Native Conversion Map

## Your Actual Web App Structure → React Native Structure

### Web (Next.js App Router) → Mobile (Expo Router)

```
app/(auth)/                    → app/(auth)/
├── login/page.tsx             → login.tsx
├── register/page.tsx          → register.tsx
└── forgot-password/page.tsx   → forgot-password.tsx

app/(dashboard)/[orgId]/       → app/(app)/(tabs)/
├── dashboard/page.tsx         → dashboard.tsx (index)
├── flow-map/page.tsx          → flow-map.tsx
├── properties/[propertyId]/   → property/[id].tsx
├── rooms/page.tsx             → rooms.tsx
├── settings/page.tsx          → settings.tsx
└── users/page.tsx             → users.tsx

app/org/[orgId]/               → app/org/[id].tsx
app/property/[propertyId]/     → app/property/[id].tsx
app/tickets/[ticketId]/        → app/ticket/[id].tsx
```

### Components Mapping

```
@/frontend/components/layout/ContextBar     → src/components/layout/ContextBar.tsx
@/frontend/components/layout/DashboardSidebar → src/components/layout/Sidebar.tsx
@/frontend/components/ui/Loader              → src/components/ui/Loader.tsx
@/frontend/components/ui/Button              → src/components/ui/Button.tsx (use Tamagui)
@/frontend/components/ui/Input               → src/components/ui/Input.tsx (use Tamagui)
```

### Context/Hooks Mapping

```
@/frontend/context/AuthContext    → src/context/AuthContext.tsx
@/frontend/hooks/useTickets       → src/hooks/useTickets.ts
@/frontend/hooks/useUsers         → src/hooks/useUsers.ts
@/lib/supabase/client.ts          → src/lib/supabase.ts
```

### Web → Mobile Component Equivalents

| Web (Next.js) | Mobile (React Native) |
|--------------|----------------------|
| `<div>` | `<View>` |
| `<span>`, `<p>` | `<Text>` |
| `<button>` | `<TouchableOpacity>` or `<Pressable>` |
| `<input>` | `<TextInput>` |
| `<img>` | `<Image>` |
| `<a>` | `<Link>` (from expo-router) |
| `useRouter()` | `useRouter()` (from expo-router) |
| `useState()` | `useState()` (same) |
| `useEffect()` | `useEffect()` (same) |
| Tailwind classes | StyleSheet or Tamagui props |
| `className="..."` | `style={styles...}` |

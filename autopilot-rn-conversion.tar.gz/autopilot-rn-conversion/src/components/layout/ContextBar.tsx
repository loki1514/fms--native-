// CONVERTED from: @/frontend/components/layout/ContextBar
'use client';

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { usePathname } from 'expo-router';

export function ContextBar() {
  const pathname = usePathname();
  
  // Get page title from pathname
  const getPageTitle = () => {
    if (pathname?.includes('dashboard')) return 'Dashboard';
    if (pathname?.includes('tickets')) return 'Tickets';
    if (pathname?.includes('visitors')) return 'Visitors';
    if (pathname?.includes('inventory')) return 'Inventory';
    if (pathname?.includes('rooms')) return 'Meeting Rooms';
    if (pathname?.includes('settings')) return 'Settings';
    if (pathname?.includes('users')) return 'Users';
    return 'Autopilot';
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{getPageTitle()}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 56,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111827',
  },
});

export default ContextBar;

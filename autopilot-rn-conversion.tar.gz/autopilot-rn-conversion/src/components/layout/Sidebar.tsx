// CONVERTED from: @/frontend/components/layout/DashboardSidebar
'use client';

import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Modal,
  ScrollView,
} from 'react-native';
import { useRouter, usePathname } from 'expo-router';
import { useAuth } from '@/src/context/AuthContext';

interface SidebarProps {
  isMobileOpen: boolean;
  onMobileClose: () => void;
}

interface NavItemProps {
  label: string;
  href: string;
  icon: string;
  isActive?: boolean;
  onPress: () => void;
}

function NavItem({ label, isActive, onPress }: NavItemProps) {
  return (
    <TouchableOpacity
      style={[styles.navItem, isActive && styles.navItemActive]}
      onPress={onPress}
    >
      <View style={[styles.navIcon, isActive && styles.navIconActive]} />
      <Text style={[styles.navLabel, isActive && styles.navLabelActive]}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

export function Sidebar({ isMobileOpen, onMobileClose }: SidebarProps) {
  const router = useRouter();
  const pathname = usePathname();
  const { user, signOut } = useAuth();

  const navItems = [
    { label: 'Dashboard', href: '/(app)/(tabs)/dashboard', icon: 'home' },
    { label: 'Tickets', href: '/(app)/(tabs)/tickets', icon: 'ticket' },
    { label: 'Visitors', href: '/(app)/(tabs)/visitors', icon: 'users' },
    { label: 'Inventory', href: '/(app)/(tabs)/inventory', icon: 'package' },
    { label: 'Rooms', href: '/(app)/rooms', icon: 'calendar' },
    { label: 'Settings', href: '/(app)/(tabs)/settings', icon: 'settings' },
  ];

  const handleNavigation = (href: string) => {
    router.push(href as any);
    onMobileClose();
  };

  const handleSignOut = async () => {
    await signOut();
    router.replace('/(auth)/login');
  };

  // Mobile Sidebar (Modal)
  const MobileSidebar = (
    <Modal
      visible={isMobileOpen}
      transparent
      animationType="slide"
      onRequestClose={onMobileClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.mobileSidebar}>
          <View style={styles.sidebarHeader}>
            <View style={styles.logo}>
              <Text style={styles.logoText}>A</Text>
            </View>
            <Text style={styles.appName}>Autopilot</Text>
          </View>

          <ScrollView style={styles.navItems}>
            {navItems.map((item) => (
              <NavItem
                key={item.href}
                label={item.label}
                href={item.href}
                icon={item.icon}
                isActive={pathname?.startsWith(item.href)}
                onPress={() => handleNavigation(item.href)}
              />
            ))}
          </ScrollView>

          <View style={styles.sidebarFooter}>
            <View style={styles.userInfo}>
              <View style={styles.userAvatar}>
                <Text style={styles.userInitial}>
                  {user?.name?.[0] || user?.email?.[0] || 'U'}
                </Text>
              </View>
              <View style={styles.userDetails}>
                <Text style={styles.userName}>{user?.name || 'User'}</Text>
                <Text style={styles.userEmail}>{user?.email}</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.signOutButton} onPress={handleSignOut}>
              <Text style={styles.signOutText}>Sign Out</Text>
            </TouchableOpacity>
          </View>
        </View>
        <TouchableOpacity style={styles.overlay} onPress={onMobileClose} />
      </View>
    </Modal>
  );

  return (
    <>
      {MobileSidebar}
      {/* Desktop Sidebar - would be shown on larger screens */}
    </>
  );
}

export function MobileHeader({ onMenuToggle }: { onMenuToggle: () => void }) {
  return (
    <View style={styles.mobileHeader}>
      <TouchableOpacity style={styles.menuButton} onPress={onMenuToggle}>
        <View style={styles.menuIcon}>
          <View style={styles.menuLine} />
          <View style={styles.menuLine} />
          <View style={styles.menuLine} />
        </View>
      </TouchableOpacity>
      <Text style={styles.headerTitle}>Autopilot</Text>
      <View style={styles.placeholder} />
    </View>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    flexDirection: 'row',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  mobileSidebar: {
    width: 280,
    backgroundColor: '#fff',
    flexDirection: 'column',
  },
  sidebarHeader: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  logo: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: '#3b82f6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  appName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
  },
  navItems: {
    flex: 1,
    padding: 12,
  },
  navItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 4,
  },
  navItemActive: {
    backgroundColor: '#eff6ff',
  },
  navIcon: {
    width: 20,
    height: 20,
    borderRadius: 4,
    backgroundColor: '#d1d5db',
    marginRight: 12,
  },
  navIconActive: {
    backgroundColor: '#3b82f6',
  },
  navLabel: {
    fontSize: 14,
    color: '#374151',
  },
  navLabelActive: {
    color: '#3b82f6',
    fontWeight: '600',
  },
  sidebarFooter: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  userAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#3b82f6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  userInitial: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#fff',
  },
  userDetails: {
    flex: 1,
  },
  userName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
  },
  userEmail: {
    fontSize: 12,
    color: '#6b7280',
  },
  signOutButton: {
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 8,
    backgroundColor: '#fee2e2',
  },
  signOutText: {
    color: '#dc2626',
    fontSize: 14,
    fontWeight: '600',
  },
  mobileHeader: {
    height: 56,
    backgroundColor: '#fff',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  menuButton: {
    padding: 8,
  },
  menuIcon: {
    width: 24,
    height: 18,
    justifyContent: 'space-between',
  },
  menuLine: {
    width: 24,
    height: 2,
    backgroundColor: '#374151',
    borderRadius: 1,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
  },
  placeholder: {
    width: 40,
  },
});

export default Sidebar;

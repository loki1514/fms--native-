// CONVERTED from: @/frontend/components/ui/Loader
'use client';

import React from 'react';
import { View, ActivityIndicator, Text, StyleSheet } from 'react-native';

interface LoaderProps {
  size?: 'sm' | 'md' | 'lg';
  text?: string;
  color?: string;
}

export function Loader({ size = 'md', text, color = '#3b82f6' }: LoaderProps) {
  const indicatorSize = size === 'sm' ? 'small' : size === 'lg' ? 'large' : 'large';
  const scale = size === 'md' ? 1 : size === 'lg' ? 1.5 : 0.8;

  return (
    <View style={styles.container}>
      <ActivityIndicator
        size={indicatorSize}
        color={color}
        style={{ transform: [{ scale }] }}
      />
      {text && <Text style={[styles.text, { color }]}>{text}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  text: {
    fontSize: 14,
    fontWeight: '500',
  },
});

export default Loader;

import { config } from '@tamagui/config';
import { createTamagui } from 'tamagui';

// Create Tamagui config
export const tamaguiConfig = createTamagui({
  ...config,
  themes: {
    light: {
      background: '#ffffff',
      backgroundHover: '#f9fafb',
      backgroundPress: '#f3f4f6',
      backgroundFocus: '#e5e7eb',
      backgroundStrong: '#f3f4f6',
      backgroundTransparent: 'rgba(255, 255, 255, 0)',
      
      color: '#111827',
      colorHover: '#1f2937',
      colorPress: '#374151',
      colorFocus: '#4b5563',
      
      borderColor: '#e5e7eb',
      borderColorHover: '#d1d5db',
      borderColorPress: '#9ca3af',
      borderColorFocus: '#6b7280',
      
      placeholderColor: '#9ca3af',
      
      // Brand colors
      primary: '#3b82f6',
      primaryHover: '#2563eb',
      primaryPress: '#1d4ed8',
      
      secondary: '#8b5cf6',
      secondaryHover: '#7c3aed',
      secondaryPress: '#6d28d9',
      
      success: '#22c55e',
      successHover: '#16a34a',
      successPress: '#15803d',
      
      warning: '#f59e0b',
      warningHover: '#d97706',
      warningPress: '#b45309',
      
      danger: '#ef4444',
      dangerHover: '#dc2626',
      dangerPress: '#b91c1c',
      
      info: '#3b82f6',
      infoHover: '#2563eb',
      infoPress: '#1d4ed8',
    },
    dark: {
      background: '#111827',
      backgroundHover: '#1f2937',
      backgroundPress: '#374151',
      backgroundFocus: '#4b5563',
      backgroundStrong: '#1f2937',
      backgroundTransparent: 'rgba(17, 24, 39, 0)',
      
      color: '#f9fafb',
      colorHover: '#f3f4f6',
      colorPress: '#e5e7eb',
      colorFocus: '#d1d5db',
      
      borderColor: '#374151',
      borderColorHover: '#4b5563',
      borderColorPress: '#6b7280',
      borderColorFocus: '#9ca3af',
      
      placeholderColor: '#6b7280',
      
      // Brand colors
      primary: '#60a5fa',
      primaryHover: '#3b82f6',
      primaryPress: '#2563eb',
      
      secondary: '#a78bfa',
      secondaryHover: '#8b5cf6',
      secondaryPress: '#7c3aed',
      
      success: '#4ade80',
      successHover: '#22c55e',
      successPress: '#16a34a',
      
      warning: '#fbbf24',
      warningHover: '#f59e0b',
      warningPress: '#d97706',
      
      danger: '#f87171',
      dangerHover: '#ef4444',
      dangerPress: '#dc2626',
      
      info: '#60a5fa',
      infoHover: '#3b82f6',
      infoPress: '#2563eb',
    },
  },
  tokens: {
    ...config.tokens,
    color: {
      ...config.tokens.color,
      // Add custom colors
      brand: '#3b82f6',
      'brand-dark': '#2563eb',
      'brand-light': '#60a5fa',
    },
    size: {
      ...config.tokens.size,
      // Custom sizes
      xs: 4,
      sm: 8,
      md: 16,
      lg: 24,
      xl: 32,
      '2xl': 48,
      '3xl': 64,
    },
    space: {
      ...config.tokens.space,
      // Custom spacing
      xs: 4,
      sm: 8,
      md: 16,
      lg: 24,
      xl: 32,
      '2xl': 48,
      '3xl': 64,
    },
    radius: {
      ...config.tokens.radius,
      // Custom border radius
      xs: 2,
      sm: 4,
      md: 8,
      lg: 12,
      xl: 16,
      '2xl': 24,
      full: 9999,
    },
  },
  fonts: {
    ...config.fonts,
    body: {
      ...config.fonts.body,
      family: 'Inter, system-ui, sans-serif',
    },
    heading: {
      ...config.fonts.heading,
      family: 'Inter, system-ui, sans-serif',
    },
  },
});

// Export type helper
type Conf = typeof tamaguiConfig;
declare module 'tamagui' {
  interface TamaguiCustomConfig extends Conf {}
}

export default tamaguiConfig;

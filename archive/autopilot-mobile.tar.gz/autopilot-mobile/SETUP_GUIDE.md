# Autopilot Mobile - Complete Setup Guide

This guide will walk you through setting up, building, and deploying your React Native mobile app to the Apple App Store and Google Play Store.

## 📋 Table of Contents

1. [Initial Setup](#initial-setup)
2. [Development Environment](#development-environment)
3. [Building for Production](#building-for-production)
4. [App Store Deployment](#app-store-deployment)
5. [Google Play Deployment](#google-play-deployment)
6. [Post-Deployment](#post-deployment)

---

## Initial Setup

### 1. Install Dependencies

```bash
cd /mnt/okcomputer/output/autopilot-mobile
npm install
```

### 2. Set Up Expo Account

1. Create an account at [expo.dev](https://expo.dev)
2. Login via CLI:
```bash
npx expo login
```

### 3. Initialize EAS Project

```bash
# Install EAS CLI
npm install -g eas-cli

# Initialize EAS project
eas init
```

This will create an EAS project and update your `app.json` with the project ID.

### 4. Update Environment Variables

Your `.env` file is pre-configured. Verify these values:

```env
EXPO_PUBLIC_SUPABASE_URL=https://xvucakstcmtfoanmgcql.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh2dWNha3N0Y210Zm9hbm1nY3FsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjczMjI0NjUsImV4cCI6MjA4Mjg5ODQ2NX0.7Uh38WHaPfrgp9lxX-BG7PXehR_-2ETG4cyQ55YfD-o
EXPO_PUBLIC_GROQ_API_KEY=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
EXPO_PUBLIC_GROQ_LAYOUT_API_KEY=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
```

---

## Development Environment

### Start Development Server

```bash
npx expo start
```

### Run on iOS Simulator (macOS only)

```bash
# Press 'i' in the terminal after starting expo
# Or run directly:
npx expo run:ios
```

### Run on Android Emulator

```bash
# Press 'a' in the terminal after starting expo
# Or run directly:
npx expo run:android
```

### Run on Physical Device

1. Install **Expo Go** app from App Store/Play Store
2. Scan QR code shown in terminal
3. App will load on your device

---

## Building for Production

### iOS Build

#### Step 1: Configure App.json

Update `app.json` with your Apple Team ID:

```json
{
  "expo": {
    "ios": {
      "bundleIdentifier": "com.autopilot.offices",
      "buildNumber": "1.0.0"
    }
  }
}
```

#### Step 2: Generate Icons

Create app icons in these sizes:
- 1024×1024px (App Store)
- 180×180px (iPhone)
- 167×167px (iPad)
- 152×152px (iPad)
- 120×120px (iPhone)

Place them in `assets/images/` and update `app.json`.

#### Step 3: Build with EAS

```bash
# Development build (for testing)
eas build --platform ios --profile development

# Preview build (internal distribution)
eas build --platform ios --profile preview

# Production build (App Store)
eas build --platform ios --profile production
```

#### Step 4: Configure App Store Connect

1. Go to [App Store Connect](https://appstoreconnect.apple.com)
2. Create new app with bundle ID: `com.autopilot.offices`
3. Fill in app details (name, description, screenshots)
4. Set up pricing and availability

### Android Build

#### Step 1: Configure App.json

```json
{
  "expo": {
    "android": {
      "package": "com.autopilot.offices",
      "versionCode": 1,
      "adaptiveIcon": {
        "foregroundImage": "./assets/images/adaptive-icon.png",
        "backgroundColor": "#FFFFFF"
      }
    }
  }
}
```

#### Step 2: Generate Icons

Create:
- 512×512px (Play Store)
- Adaptive icon (foreground + background)
- 1024×500px feature graphic

#### Step 3: Build with EAS

```bash
# Development build
eas build --platform android --profile development

# Preview build (APK)
eas build --platform android --profile preview

# Production build (AAB for Play Store)
eas build --platform android --profile production
```

---

## App Store Deployment

### Prerequisites

- Apple Developer Program membership ($99/year)
- macOS with Xcode installed
- App Store Connect account

### Step-by-Step Deployment

#### 1. Archive Build

```bash
eas build --platform ios --profile production --local
```

Or use EAS cloud build:
```bash
eas build --platform ios --profile production
```

#### 2. Upload to App Store Connect

Using EAS Submit:
```bash
eas submit --platform ios --profile production
```

Or manually via Xcode:
1. Open `.xcarchive` in Xcode
2. Click "Distribute App"
3. Select "App Store Connect"
4. Follow upload wizard

#### 3. Configure in App Store Connect

1. Go to [App Store Connect](https://appstoreconnect.apple.com)
2. Select your app
3. Fill in:
   - **App Information**: Name, subtitle, category
   - **Pricing and Availability**: Price, territories
   - **App Privacy**: Privacy policy URL, data usage
   - **Screenshots**: For all required devices
   - **Build**: Select uploaded build

#### 4. Submit for Review

1. Click "Add for Review"
2. Answer export compliance questions
3. Submit for review

**Review Time**: Typically 24-48 hours

---

## Google Play Deployment

### Prerequisites

- Google Play Developer account ($25 one-time)
- Google Cloud project (for API access)

### Step-by-Step Deployment

#### 1. Create App in Play Console

1. Go to [Google Play Console](https://play.google.com/console)
2. Click "Create app"
3. Fill in app details:
   - App name: Autopilot
   - Default language: English
   - App or game: App
   - Free or paid: Free

#### 2. Set Up App Signing

1. Go to **Setup** → **App integrity**
2. Choose signing option (Google-managed recommended)
3. Upload signing key or generate new one

#### 3. Upload AAB File

```bash
# Build production AAB
eas build --platform android --profile production

# Or submit directly
eas submit --platform android --profile production
```

Manual upload:
1. Go to **Production** → **Create new release**
2. Upload AAB file
3. Add release notes

#### 4. Complete Store Listing

Fill in all required sections:
- **App access**: Free/Subscription
- **Ads**: No ads
- **Content rating**: Complete questionnaire
- **Target audience**: 18+
- **News apps**: No
- **COVID-19**: No
- **Data safety**: Complete form with data usage
- **Privacy policy**: Add URL

#### 5. Set Up Pricing & Distribution

1. Go to **Monetize** → **Pricing & distribution**
2. Select countries
3. Set price (free)
4. Enable Google Play for Education (optional)

#### 6. Submit for Review

1. Review all sections (green checkmarks)
2. Click **Start rollout to Production**
3. Confirm rollout

**Review Time**: Typically 1-3 days

---

## Post-Deployment

### Monitoring

Set up monitoring tools:

```bash
# Install Sentry for crash reporting
npm install @sentry/react-native

# Install analytics
npm install @segment/analytics-react-native
```

### Updates

Use EAS Update for OTA updates:

```bash
# Publish update
eas update --channel production --message "Bug fixes"
```

### Version Management

Update version in `app.json`:

```json
{
  "version": "1.1.0",
  "ios": {
    "buildNumber": "1.1.0"
  },
  "android": {
    "versionCode": 2
  }
}
```

---

## Troubleshooting

### Build Failures

**iOS:**
```bash
# Clean build
cd ios && xcodebuild clean

# Reinstall pods
npx pod-install

# Clear derived data
rm -rf ~/Library/Developer/Xcode/DerivedData
```

**Android:**
```bash
# Clean build
cd android && ./gradlew clean

# Clear gradle cache
rm -rf ~/.gradle/caches
```

### Common Errors

**"Bundle identifier not available"**
- Check if bundle ID is unique
- Verify Apple Developer account

**"Keystore error"**
```bash
# Generate new keystore
eas credentials:manager
```

**"Push notifications not working"**
- Verify APNs certificates in Apple Developer portal
- Check Firebase configuration for Android

---

## Quick Reference

### Commands

```bash
# Development
npx expo start                    # Start dev server
npx expo run:ios                  # Run on iOS
npx expo run:android              # Run on Android

# Building
eas build --platform ios         # Build iOS
eas build --platform android     # Build Android

# Submitting
eas submit --platform ios        # Submit to App Store
eas submit --platform android    # Submit to Play Store

# Updates
eas update --channel production  # Publish OTA update

# Credentials
eas credentials:manager          # Manage credentials
```

### File Locations

| File | Purpose |
|------|---------|
| `app.json` | Expo configuration |
| `eas.json` | EAS Build configuration |
| `.env` | Environment variables |
| `tamagui.config.ts` | UI theme configuration |
| `src/services/supabase.ts` | Backend integration |

### Support Resources

- [Expo Documentation](https://docs.expo.dev)
- [EAS Build Documentation](https://docs.expo.dev/build/introduction/)
- [App Store Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
- [Google Play Policy Center](https://support.google.com/googleplay/android-developer/topic/9858052)

---

## Next Steps

1. ✅ Review all configuration files
2. ✅ Add app icons and splash screen
3. ✅ Test on physical devices
4. ✅ Set up developer accounts
5. ✅ Build and submit to stores
6. ✅ Set up analytics and monitoring
7. ✅ Plan update strategy

**You're ready to launch! 🚀**

import Constants from 'expo-constants';

// App Info
export const APP_NAME = Constants.expoConfig?.name || 'Autopilot';
export const APP_VERSION = Constants.expoConfig?.version || '1.0.0';

// Supabase Configuration
export const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL || '';
export const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';

// API Configuration
export const API_BASE_URL = process.env.EXPO_PUBLIC_API_BASE_URL || '';
export const GROQ_API_KEY = process.env.EXPO_PUBLIC_GROQ_API_KEY || '';
export const GROQ_LAYOUT_API_KEY = process.env.EXPO_PUBLIC_GROQ_LAYOUT_API_KEY || '';

// Feature Flags
export const ENABLE_BIOMETRIC_AUTH = process.env.EXPO_PUBLIC_ENABLE_BIOMETRIC_AUTH === 'true';
export const ENABLE_PUSH_NOTIFICATIONS = process.env.EXPO_PUBLIC_ENABLE_PUSH_NOTIFICATIONS === 'true';
export const ENABLE_OFFLINE_MODE = process.env.EXPO_PUBLIC_ENABLE_OFFLINE_MODE === 'true';

// Pagination
export const DEFAULT_PAGE_SIZE = 20;
export const MAX_PAGE_SIZE = 100;

// Cache Keys
export const CACHE_KEYS = {
  USER: 'user',
  SESSION: 'session',
  THEME: 'theme',
  NOTIFICATIONS: 'notifications',
  OFFLINE_QUEUE: 'offline_queue',
  LAST_SYNC: 'last_sync',
} as const;

// Ticket Configuration
export const TICKET_PRIORITIES = [
  { value: 'low', label: 'Low', color: '#22c55e' },
  { value: 'medium', label: 'Medium', color: '#f59e0b' },
  { value: 'high', label: 'High', color: '#ef4444' },
  { value: 'urgent', label: 'Urgent', color: '#dc2626' },
] as const;

export const TICKET_STATUSES = [
  { value: 'open', label: 'Open', color: '#3b82f6' },
  { value: 'in_progress', label: 'In Progress', color: '#f59e0b' },
  { value: 'resolved', label: 'Resolved', color: '#22c55e' },
  { value: 'closed', label: 'Closed', color: '#6b7280' },
  { value: 'on_hold', label: 'On Hold', color: '#8b5cf6' },
] as const;

// Visitor Configuration
export const VISITOR_STATUSES = [
  { value: 'expected', label: 'Expected', color: '#3b82f6' },
  { value: 'checked_in', label: 'Checked In', color: '#22c55e' },
  { value: 'checked_out', label: 'Checked Out', color: '#6b7280' },
  { value: 'overstayed', label: 'Overstayed', color: '#ef4444' },
] as const;

// User Roles
export const USER_ROLES = [
  { value: 'master_admin', label: 'Master Admin' },
  { value: 'org_admin', label: 'Organization Admin' },
  { value: 'property_admin', label: 'Property Admin' },
  { value: 'property_manager', label: 'Property Manager' },
  { value: 'mst', label: 'MST' },
  { value: 'client', label: 'Client' },
  { value: 'super_tenant', label: 'Super Tenant' },
  { value: 'vendor', label: 'Vendor' },
] as const;

// Property Types
export const PROPERTY_TYPES = [
  { value: 'residential', label: 'Residential' },
  { value: 'commercial', label: 'Commercial' },
  { value: 'industrial', label: 'Industrial' },
  { value: 'mixed_use', label: 'Mixed Use' },
] as const;

// Date Formats
export const DATE_FORMATS = {
  DISPLAY: 'MMM dd, yyyy',
  DISPLAY_WITH_TIME: 'MMM dd, yyyy h:mm a',
  ISO: "yyyy-MM-dd'T'HH:mm:ss.SSSxxx",
  SHORT: 'MMM dd',
  TIME: 'h:mm a',
} as const;

// Validation
export const VALIDATION = {
  MIN_PASSWORD_LENGTH: 8,
  MAX_PASSWORD_LENGTH: 128,
  MIN_NAME_LENGTH: 2,
  MAX_NAME_LENGTH: 100,
  PHONE_REGEX: /^\+?[1-9]\d{1,14}$/,
  EMAIL_REGEX: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
} as const;

// Error Messages
export const ERROR_MESSAGES = {
  REQUIRED: 'This field is required',
  INVALID_EMAIL: 'Please enter a valid email address',
  INVALID_PHONE: 'Please enter a valid phone number',
  MIN_PASSWORD: `Password must be at least ${VALIDATION.MIN_PASSWORD_LENGTH} characters`,
  PASSWORD_MISMATCH: 'Passwords do not match',
  INVALID_CREDENTIALS: 'Invalid email or password',
  NETWORK_ERROR: 'Network error. Please check your connection.',
  UNKNOWN_ERROR: 'An unexpected error occurred. Please try again.',
  OFFLINE_MODE: 'You are offline. Changes will sync when connected.',
} as const;

// Success Messages
export const SUCCESS_MESSAGES = {
  LOGIN_SUCCESS: 'Welcome back!',
  REGISTER_SUCCESS: 'Account created successfully!',
  TICKET_CREATED: 'Ticket created successfully',
  TICKET_UPDATED: 'Ticket updated successfully',
  VISITOR_CHECKED_IN: 'Visitor checked in successfully',
  VISITOR_CHECKED_OUT: 'Visitor checked out successfully',
  INVENTORY_UPDATED: 'Inventory updated successfully',
  BOOKING_CREATED: 'Booking created successfully',
  PROFILE_UPDATED: 'Profile updated successfully',
  SETTINGS_SAVED: 'Settings saved successfully',
} as const;

// Deep Linking
export const DEEP_LINKS = {
  TICKET: 'autopilot://ticket/',
  VISITOR: 'autopilot://visitor/',
  INVENTORY: 'autopilot://inventory/',
  BOOKING: 'autopilot://booking/',
  RESET_PASSWORD: 'autopilot://reset-password/',
} as const;

// Push Notification Channels
export const NOTIFICATION_CHANNELS = {
  DEFAULT: 'default',
  TICKETS: 'tickets',
  VISITORS: 'visitors',
  INVENTORY: 'inventory',
  SYSTEM: 'system',
} as const;

// Biometric Types
export const BIOMETRIC_TYPES = {
  FACE_ID: 'FaceID',
  TOUCH_ID: 'TouchID',
  FINGERPRINT: 'Fingerprint',
  IRIS: 'Iris',
} as const;

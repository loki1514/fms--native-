import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { User, AuthSession } from '@types';
import * as SecureStore from 'expo-secure-store';

interface AuthState {
  // State
  user: User | null;
  session: AuthSession | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isBiometricEnabled: boolean;
  
  // Actions
  setUser: (user: User | null) => void;
  setSession: (session: AuthSession | null) => void;
  setAuthenticated: (value: boolean) => void;
  setLoading: (value: boolean) => void;
  setBiometricEnabled: (value: boolean) => void;
  logout: () => Promise<void>;
  clearAuth: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      // Initial state
      user: null,
      session: null,
      isAuthenticated: false,
      isLoading: true,
      isBiometricEnabled: false,
      
      // Actions
      setUser: (user) => {
        set({ user, isAuthenticated: !!user });
      },
      
      setSession: (session) => {
        set({ session });
      },
      
      setAuthenticated: (value) => {
        set({ isAuthenticated: value });
      },
      
      setLoading: (value) => {
        set({ isLoading: value });
      },
      
      setBiometricEnabled: (value) => {
        set({ isBiometricEnabled: value });
      },
      
      logout: async () => {
        // Clear secure storage
        await SecureStore.deleteItemAsync('session');
        await SecureStore.deleteItemAsync('refreshToken');
        
        // Clear state
        set({
          user: null,
          session: null,
          isAuthenticated: false,
          isBiometricEnabled: false,
        });
      },
      
      clearAuth: () => {
        set({
          user: null,
          session: null,
          isAuthenticated: false,
          isLoading: false,
        });
      },
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        isBiometricEnabled: state.isBiometricEnabled,
      }),
    }
  )
);

// Selectors
export const selectUser = (state: AuthState) => state.user;
export const selectIsAuthenticated = (state: AuthState) => state.isAuthenticated;
export const selectIsLoading = (state: AuthState) => state.isLoading;
export const selectUserRole = (state: AuthState) => state.user?.role;
export const selectIsBiometricEnabled = (state: AuthState) => state.isBiometricEnabled;

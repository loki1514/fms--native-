import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useColorScheme } from 'react-native';
import type { Theme } from '@types';

interface ThemeState {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set, get) => ({
      theme: 'system',
      setTheme: (theme) => set({ theme }),
      toggleTheme: () => {
        const currentTheme = get().theme;
        const systemColorScheme = useColorScheme();
        
        if (currentTheme === 'system') {
          set({ theme: systemColorScheme === 'dark' ? 'light' : 'dark' });
        } else {
          set({ theme: currentTheme === 'dark' ? 'light' : 'dark' });
        }
      },
    }),
    {
      name: 'theme-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);

// Hook to get the actual color scheme (resolved)
export const useResolvedColorScheme = () => {
  const systemColorScheme = useColorScheme();
  const theme = useThemeStore((state) => state.theme);
  
  if (theme === 'system') {
    return systemColorScheme ?? 'light';
  }
  
  return theme;
};

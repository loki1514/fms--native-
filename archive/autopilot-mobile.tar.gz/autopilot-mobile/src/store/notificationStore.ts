import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Notification } from '@types';

interface NotificationState {
  // State
  notifications: Notification[];
  unreadCount: number;
  pushToken: string | null;
  isPushEnabled: boolean;
  
  // Actions
  setNotifications: (notifications: Notification[]) => void;
  addNotification: (notification: Notification) => void;
  markAsRead: (notificationId: string) => void;
  markAllAsRead: () => void;
  removeNotification: (notificationId: string) => void;
  clearAll: () => void;
  setPushToken: (token: string | null) => void;
  setPushEnabled: (enabled: boolean) => void;
  updateUnreadCount: () => void;
}

export const useNotificationStore = create<NotificationState>()(
  persist(
    (set, get) => ({
      // Initial state
      notifications: [],
      unreadCount: 0,
      pushToken: null,
      isPushEnabled: false,
      
      // Actions
      setNotifications: (notifications) => {
        set({ notifications });
        get().updateUnreadCount();
      },
      
      addNotification: (notification) => {
        set((state) => ({
          notifications: [notification, ...state.notifications],
        }));
        get().updateUnreadCount();
      },
      
      markAsRead: (notificationId) => {
        set((state) => ({
          notifications: state.notifications.map((n) =>
            n.id === notificationId ? { ...n, read: true } : n
          ),
        }));
        get().updateUnreadCount();
      },
      
      markAllAsRead: () => {
        set((state) => ({
          notifications: state.notifications.map((n) => ({ ...n, read: true })),
        }));
        get().updateUnreadCount();
      },
      
      removeNotification: (notificationId) => {
        set((state) => ({
          notifications: state.notifications.filter((n) => n.id !== notificationId),
        }));
        get().updateUnreadCount();
      },
      
      clearAll: () => {
        set({ notifications: [], unreadCount: 0 });
      },
      
      setPushToken: (token) => {
        set({ pushToken: token });
      },
      
      setPushEnabled: (enabled) => {
        set({ isPushEnabled: enabled });
      },
      
      updateUnreadCount: () => {
        const { notifications } = get();
        const unreadCount = notifications.filter((n) => !n.read).length;
        set({ unreadCount });
      },
    }),
    {
      name: 'notification-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        notifications: state.notifications.slice(0, 100), // Keep only last 100
        isPushEnabled: state.isPushEnabled,
        pushToken: state.pushToken,
      }),
    }
  )
);

// Selectors
export const selectNotifications = (state: NotificationState) => state.notifications;
export const selectUnreadCount = (state: NotificationState) => state.unreadCount;
export const selectPushToken = (state: NotificationState) => state.pushToken;
export const selectIsPushEnabled = (state: NotificationState) => state.isPushEnabled;

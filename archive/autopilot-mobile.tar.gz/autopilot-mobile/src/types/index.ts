// User Types
export interface User {
  id: string;
  email: string;
  role: UserRole;
  firstName: string;
  lastName: string;
  avatar?: string;
  organizationId?: string;
  propertyId?: string;
  createdAt: string;
  updatedAt: string;
}

export type UserRole = 
  | 'master_admin'
  | 'org_admin'
  | 'property_admin'
  | 'property_manager'
  | 'mst'
  | 'client'
  | 'super_tenant'
  | 'vendor';

// Auth Types
export interface AuthSession {
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
  expiresAt: number | null;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterCredentials {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  organizationId?: string;
}

// Ticket Types
export interface Ticket {
  id: string;
  title: string;
  description: string;
  status: TicketStatus;
  priority: TicketPriority;
  category: string;
  createdBy: string;
  assignedTo?: string;
  propertyId: string;
  organizationId: string;
  attachments?: string[];
  createdAt: string;
  updatedAt: string;
  dueDate?: string;
  resolution?: string;
}

export type TicketStatus = 'open' | 'in_progress' | 'resolved' | 'closed' | 'on_hold';
export type TicketPriority = 'low' | 'medium' | 'high' | 'urgent';

// Visitor Types
export interface Visitor {
  id: string;
  name: string;
  email?: string;
  phone: string;
  company?: string;
  purpose: string;
  hostName: string;
  hostId?: string;
  checkInTime: string;
  checkOutTime?: string;
  status: VisitorStatus;
  photo?: string;
  passCode?: string;
  propertyId: string;
  preRegistered: boolean;
}

export type VisitorStatus = 'expected' | 'checked_in' | 'checked_out' | 'overstayed';

// Inventory Types
export interface InventoryItem {
  id: string;
  name: string;
  sku: string;
  category: string;
  quantity: number;
  minQuantity: number;
  unit: string;
  location: string;
  propertyId: string;
  qrCode?: string;
  lastRestocked?: string;
  supplier?: string;
  costPerUnit?: number;
}

export interface StockTransaction {
  id: string;
  itemId: string;
  type: 'in' | 'out';
  quantity: number;
  reason: string;
  performedBy: string;
  timestamp: string;
  notes?: string;
}

// Property Types
export interface Property {
  id: string;
  name: string;
  address: string;
  type: PropertyType;
  organizationId: string;
  managerId?: string;
  totalUnits: number;
  occupiedUnits: number;
  amenities: string[];
  createdAt: string;
}

export type PropertyType = 'residential' | 'commercial' | 'industrial' | 'mixed_use';

// Meeting Room Types
export interface MeetingRoom {
  id: string;
  name: string;
  capacity: number;
  amenities: string[];
  propertyId: string;
  floor: string;
  isActive: boolean;
}

export interface Booking {
  id: string;
  roomId: string;
  title: string;
  organizerId: string;
  startTime: string;
  endTime: string;
  attendees: string[];
  status: BookingStatus;
  notes?: string;
}

export type BookingStatus = 'confirmed' | 'cancelled' | 'completed';

// Notification Types
export interface Notification {
  id: string;
  userId: string;
  title: string;
  body: string;
  type: NotificationType;
  data?: Record<string, any>;
  read: boolean;
  createdAt: string;
}

export type NotificationType = 
  | 'ticket_assigned'
  | 'ticket_updated'
  | 'visitor_arrived'
  | 'stock_low'
  | 'booking_reminder'
  | 'system';

// API Response Types
export interface ApiResponse<T> {
  data: T;
  error: null | {
    message: string;
    code: string;
  };
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}

// Navigation Types
export type RootStackParamList = {
  '(auth)': undefined;
  '(app)': undefined;
};

export type AuthStackParamList = {
  login: undefined;
  register: undefined;
  forgotPassword: undefined;
};

export type AppStackParamList = {
  '(tabs)': undefined;
  ticketDetail: { ticketId: string };
  visitorDetail: { visitorId: string };
  inventoryDetail: { itemId: string };
  bookingDetail: { bookingId: string };
  profile: undefined;
  settings: undefined;
};

export type TabParamList = {
  dashboard: undefined;
  tickets: undefined;
  visitors: undefined;
  inventory: undefined;
  more: undefined;
};

// Theme Types
export type Theme = 'light' | 'dark' | 'system';

// Form Types
export interface FormFieldProps {
  name: string;
  label: string;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  error?: string;
}

import { useQuery, useMutation, useQueryClient, useInfiniteQuery } from '@tanstack/react-query';
import { fetchTickets, fetchVisitors, fetchInventory, supabase } from '@services/supabase';
import type { Ticket, Visitor, InventoryItem, Booking, MeetingRoom } from '@types';

// Tickets hooks
export const useTickets = (options?: Parameters<typeof fetchTickets>[0]) => {
  return useQuery({
    queryKey: ['tickets', options],
    queryFn: () => fetchTickets(options),
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
};

export const useInfiniteTickets = (options?: Omit<Parameters<typeof fetchTickets>[0], 'page'>) => {
  return useInfiniteQuery({
    queryKey: ['tickets', 'infinite', options],
    queryFn: ({ pageParam = 1 }) => fetchTickets({ ...options, page: pageParam }),
    getNextPageParam: (lastPage) => {
      if (lastPage.hasMore) {
        return lastPage.page + 1;
      }
      return undefined;
    },
    initialPageParam: 1,
  });
};

export const useTicket = (ticketId: string) => {
  return useQuery({
    queryKey: ['ticket', ticketId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('tickets')
        .select('*')
        .eq('id', ticketId)
        .single();
      
      if (error) throw error;
      return data as Ticket;
    },
    enabled: !!ticketId,
  });
};

export const useCreateTicket = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (ticketData: Partial<Ticket>) => {
      const { data, error } = await supabase
        .from('tickets')
        .insert(ticketData)
        .select()
        .single();
      
      if (error) throw error;
      return data as Ticket;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tickets'] });
    },
  });
};

export const useUpdateTicket = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ ticketId, updates }: { ticketId: string; updates: Partial<Ticket> }) => {
      const { data, error } = await supabase
        .from('tickets')
        .update(updates)
        .eq('id', ticketId)
        .select()
        .single();
      
      if (error) throw error;
      return data as Ticket;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['tickets'] });
      queryClient.invalidateQueries({ queryKey: ['ticket', variables.ticketId] });
    },
  });
};

// Visitors hooks
export const useVisitors = (options?: Parameters<typeof fetchVisitors>[0]) => {
  return useQuery({
    queryKey: ['visitors', options],
    queryFn: () => fetchVisitors(options),
    staleTime: 1000 * 60 * 5,
  });
};

export const useInfiniteVisitors = (options?: Omit<Parameters<typeof fetchVisitors>[0], 'page'>) => {
  return useInfiniteQuery({
    queryKey: ['visitors', 'infinite', options],
    queryFn: ({ pageParam = 1 }) => fetchVisitors({ ...options, page: pageParam }),
    getNextPageParam: (lastPage) => {
      if (lastPage.hasMore) {
        return lastPage.page + 1;
      }
      return undefined;
    },
    initialPageParam: 1,
  });
};

export const useVisitor = (visitorId: string) => {
  return useQuery({
    queryKey: ['visitor', visitorId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('visitors')
        .select('*')
        .eq('id', visitorId)
        .single();
      
      if (error) throw error;
      return data as Visitor;
    },
    enabled: !!visitorId,
  });
};

export const useCheckInVisitor = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (visitorId: string) => {
      const { data, error } = await supabase
        .from('visitors')
        .update({
          status: 'checked_in',
          check_in_time: new Date().toISOString(),
        })
        .eq('id', visitorId)
        .select()
        .single();
      
      if (error) throw error;
      return data as Visitor;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['visitors'] });
    },
  });
};

export const useCheckOutVisitor = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (visitorId: string) => {
      const { data, error } = await supabase
        .from('visitors')
        .update({
          status: 'checked_out',
          check_out_time: new Date().toISOString(),
        })
        .eq('id', visitorId)
        .select()
        .single();
      
      if (error) throw error;
      return data as Visitor;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['visitors'] });
    },
  });
};

// Inventory hooks
export const useInventory = (options?: Parameters<typeof fetchInventory>[0]) => {
  return useQuery({
    queryKey: ['inventory', options],
    queryFn: () => fetchInventory(options),
    staleTime: 1000 * 60 * 5,
  });
};

export const useInfiniteInventory = (options?: Omit<Parameters<typeof fetchInventory>[0], 'page'>) => {
  return useInfiniteQuery({
    queryKey: ['inventory', 'infinite', options],
    queryFn: ({ pageParam = 1 }) => fetchInventory({ ...options, page: pageParam }),
    getNextPageParam: (lastPage) => {
      if (lastPage.hasMore) {
        return lastPage.page + 1;
      }
      return undefined;
    },
    initialPageParam: 1,
  });
};

export const useInventoryItem = (itemId: string) => {
  return useQuery({
    queryKey: ['inventory', itemId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('inventory')
        .select('*')
        .eq('id', itemId)
        .single();
      
      if (error) throw error;
      return data as InventoryItem;
    },
    enabled: !!itemId,
  });
};

export const useUpdateStock = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ itemId, quantity, reason }: { itemId: string; quantity: number; reason: string }) => {
      // Get current item
      const { data: item, error: fetchError } = await supabase
        .from('inventory')
        .select('quantity')
        .eq('id', itemId)
        .single();
      
      if (fetchError) throw fetchError;
      
      // Update quantity
      const newQuantity = item.quantity + quantity;
      
      const { data, error } = await supabase
        .from('inventory')
        .update({ quantity: newQuantity, updated_at: new Date().toISOString() })
        .eq('id', itemId)
        .select()
        .single();
      
      if (error) throw error;
      
      // Record transaction
      await supabase.from('stock_transactions').insert({
        item_id: itemId,
        type: quantity > 0 ? 'in' : 'out',
        quantity: Math.abs(quantity),
        reason,
        performed_by: (await supabase.auth.getUser()).data.user?.id,
        timestamp: new Date().toISOString(),
      });
      
      return data as InventoryItem;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inventory'] });
    },
  });
};

// Meeting Rooms hooks
export const useMeetingRooms = (propertyId?: string) => {
  return useQuery({
    queryKey: ['meetingRooms', propertyId],
    queryFn: async () => {
      let query = supabase.from('meeting_rooms').select('*');
      
      if (propertyId) {
        query = query.eq('property_id', propertyId);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      return data as MeetingRoom[];
    },
  });
};

export const useBookings = (options?: { roomId?: string; startDate?: string; endDate?: string }) => {
  return useQuery({
    queryKey: ['bookings', options],
    queryFn: async () => {
      let query = supabase.from('bookings').select('*');
      
      if (options?.roomId) {
        query = query.eq('room_id', options.roomId);
      }
      
      if (options?.startDate) {
        query = query.gte('start_time', options.startDate);
      }
      
      if (options?.endDate) {
        query = query.lte('end_time', options.endDate);
      }
      
      const { data, error } = await query.order('start_time', { ascending: true });
      
      if (error) throw error;
      return data as Booking[];
    },
  });
};

export const useCreateBooking = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (bookingData: Partial<Booking>) => {
      const { data, error } = await supabase
        .from('bookings')
        .insert(bookingData)
        .select()
        .single();
      
      if (error) throw error;
      return data as Booking;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
    },
  });
};

// Dashboard stats hook
export const useDashboardStats = (propertyId?: string) => {
  return useQuery({
    queryKey: ['dashboardStats', propertyId],
    queryFn: async () => {
      // Fetch multiple stats in parallel
      const [
        ticketsResult,
        visitorsResult,
        inventoryResult,
      ] = await Promise.all([
        supabase
          .from('tickets')
          .select('status', { count: 'exact' })
          .eq('property_id', propertyId)
          .in('status', ['open', 'in_progress']),
        supabase
          .from('visitors')
          .select('*', { count: 'exact' })
          .eq('property_id', propertyId)
          .eq('status', 'checked_in'),
        supabase
          .from('inventory')
          .select('*', { count: 'exact' })
          .eq('property_id', propertyId)
          .lte('quantity', supabase.raw('min_quantity')),
      ]);

      return {
        openTickets: ticketsResult.count || 0,
        checkedInVisitors: visitorsResult.count || 0,
        lowStockItems: inventoryResult.count || 0,
      };
    },
    enabled: !!propertyId,
    staleTime: 1000 * 60 * 2, // 2 minutes
  });
};

// Search hook
export const useSearch = (query: string, type: 'tickets' | 'visitors' | 'inventory') => {
  return useQuery({
    queryKey: ['search', type, query],
    queryFn: async () => {
      if (!query || query.length < 2) return [];

      let searchQuery;

      switch (type) {
        case 'tickets':
          searchQuery = supabase
            .from('tickets')
            .select('*')
            .or(`title.ilike.%${query}%,description.ilike.%${query}%`)
            .limit(10);
          break;
        case 'visitors':
          searchQuery = supabase
            .from('visitors')
            .select('*')
            .or(`name.ilike.%${query}%,email.ilike.%${query}%,phone.ilike.%${query}%`)
            .limit(10);
          break;
        case 'inventory':
          searchQuery = supabase
            .from('inventory')
            .select('*')
            .or(`name.ilike.%${query}%,sku.ilike.%${query}%`)
            .limit(10);
          break;
        default:
          return [];
      }

      const { data, error } = await searchQuery;

      if (error) throw error;
      return data;
    },
    enabled: query.length >= 2,
    staleTime: 1000 * 60, // 1 minute
  });
};

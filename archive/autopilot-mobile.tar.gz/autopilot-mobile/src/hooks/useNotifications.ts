import { useEffect, useCallback } from 'react';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { useNotificationStore } from '@store/notificationStore';
import { useAuthStore } from '@store/authStore';
import { supabase } from '@services/supabase';
import { ENABLE_PUSH_NOTIFICATIONS } from '@constants';
import type { Notification } from '@types';

// Configure notification handler
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

// Hook for push notifications
export const usePushNotifications = () => {
  const { pushToken, isPushEnabled, setPushToken, setPushEnabled, addNotification } = useNotificationStore();
  const user = useAuthStore((state) => state.user);

  // Register for push notifications
  const registerForPushNotifications = useCallback(async () => {
    if (!ENABLE_PUSH_NOTIFICATIONS) return null;

    try {
      // Check if device is physical (not simulator)
      if (!Device.isDevice) {
        console.log('Push notifications require a physical device');
        return null;
      }

      // Check permissions
      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;

      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      if (finalStatus !== 'granted') {
        console.log('Push notification permission denied');
        return null;
      }

      // Get push token
      const token = (await Notifications.getExpoPushTokenAsync({
        projectId: process.env.EXPO_PUBLIC_EAS_PROJECT_ID,
      })).data;

      setPushToken(token);
      setPushEnabled(true);

      // Register token with backend
      if (user?.id) {
        await supabase.from('push_tokens').upsert({
          user_id: user.id,
          token,
          platform: Platform.OS,
          updated_at: new Date().toISOString(),
        });
      }

      // Configure Android notification channel
      if (Platform.OS === 'android') {
        await Notifications.setNotificationChannelAsync('default', {
          name: 'Default',
          importance: Notifications.AndroidImportance.MAX,
          vibrationPattern: [0, 250, 250, 250],
          lightColor: '#FF231F7C',
        });

        await Notifications.setNotificationChannelAsync('tickets', {
          name: 'Tickets',
          importance: Notifications.AndroidImportance.HIGH,
          vibrationPattern: [0, 250, 250, 250],
        });

        await Notifications.setNotificationChannelAsync('visitors', {
          name: 'Visitors',
          importance: Notifications.AndroidImportance.DEFAULT,
        });
      }

      return token;
    } catch (error) {
      console.error('Push notification registration error:', error);
      return null;
    }
  }, [user?.id, setPushToken, setPushEnabled]);

  // Unregister push notifications
  const unregisterPushNotifications = useCallback(async () => {
    try {
      if (pushToken && user?.id) {
        await supabase.from('push_tokens').delete().eq('token', pushToken);
      }
      setPushToken(null);
      setPushEnabled(false);
    } catch (error) {
      console.error('Unregister push notifications error:', error);
    }
  }, [pushToken, user?.id, setPushToken, setPushEnabled]);

  // Setup notification listeners
  useEffect(() => {
    if (!ENABLE_PUSH_NOTIFICATIONS) return;

    // Register on mount
    registerForPushNotifications();

    // Notification received while app is foregrounded
    const notificationListener = Notifications.addNotificationReceivedListener((notification) => {
      const data = notification.request.content.data as Notification;
      addNotification(data);
    });

    // Notification tapped
    const responseListener = Notifications.addNotificationResponseReceivedListener((response) => {
      const data = response.notification.request.content.data;
      
      // Handle navigation based on notification type
      if (data?.ticketId) {
        // Navigate to ticket detail
      } else if (data?.visitorId) {
        // Navigate to visitor detail
      } else if (data?.inventoryId) {
        // Navigate to inventory detail
      }
    });

    return () => {
      Notifications.removeNotificationSubscription(notificationListener);
      Notifications.removeNotificationSubscription(responseListener);
    };
  }, [registerForPushNotifications, addNotification]);

  // Schedule local notification
  const scheduleNotification = useCallback(async (title: string, body: string, data?: any, trigger?: Notifications.NotificationTriggerInput) => {
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title,
          body,
          data,
        },
        trigger: trigger || null,
      });
    } catch (error) {
      console.error('Schedule notification error:', error);
    }
  }, []);

  // Cancel all notifications
  const cancelAllNotifications = useCallback(async () => {
    try {
      await Notifications.cancelAllScheduledNotificationsAsync();
    } catch (error) {
      console.error('Cancel notifications error:', error);
    }
  }, []);

  return {
    pushToken,
    isPushEnabled,
    registerForPushNotifications,
    unregisterPushNotifications,
    scheduleNotification,
    cancelAllNotifications,
  };
};

// Hook for in-app notifications
export const useInAppNotifications = () => {
  const { notifications, unreadCount, markAsRead, markAllAsRead, removeNotification, clearAll } = useNotificationStore();

  const getUnreadNotifications = () => {
    return notifications.filter((n) => !n.read);
  };

  const getNotificationsByType = (type: string) => {
    return notifications.filter((n) => n.type === type);
  };

  return {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    removeNotification,
    clearAll,
    getUnreadNotifications,
    getNotificationsByType,
  };
};

// Hook to send local notification (for testing or immediate feedback)
export const useLocalNotification = () => {
  const sendLocalNotification = useCallback(async (title: string, body: string) => {
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title,
          body,
        },
        trigger: null, // Show immediately
      });
    } catch (error) {
      console.error('Send local notification error:', error);
    }
  }, []);

  return { sendLocalNotification };
};

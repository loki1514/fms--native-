import { useCallback, useEffect, useState } from 'react';
import { useAuthStore } from '@store/authStore';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import * as LocalAuthentication from 'expo-local-authentication';
import * as SecureStore from 'expo-secure-store';
import {
  signInWithEmail,
  signUpWithEmail,
  signOut,
  resetPassword,
  getCurrentUser,
  getSession,
  supabase,
} from '@services/supabase';
import { ENABLE_BIOMETRIC_AUTH } from '@constants';
import type { LoginCredentials, RegisterCredentials, User } from '@types';

// Hook for authentication state and actions
export const useAuth = () => {
  const queryClient = useQueryClient();
  const { user, isAuthenticated, isLoading, isBiometricEnabled, setUser, setSession, setLoading, setBiometricEnabled, logout } = useAuthStore();

  // Initialize auth state on mount
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        setLoading(true);
        
        // Check for existing session
        const session = await getSession();
        
        if (session) {
          setSession(session);
          const userData = await getCurrentUser();
          setUser(userData);
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error('Auth initialization error:', error);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session) {
        const userData = await getCurrentUser();
        setUser(userData);
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
        setSession(null);
        queryClient.clear();
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [setUser, setSession, setLoading, queryClient]);

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginCredentials) => {
      const { user, session } = await signInWithEmail(credentials.email, credentials.password);
      
      if (session) {
        setSession({
          user: user as unknown as User,
          accessToken: session.access_token,
          refreshToken: session.refresh_token,
          expiresAt: session.expires_at,
        });
      }
      
      const userData = await getCurrentUser();
      setUser(userData);
      
      return userData;
    },
  });

  // Register mutation
  const registerMutation = useMutation({
    mutationFn: async (credentials: RegisterCredentials) => {
      const { user, session } = await signUpWithEmail(
        credentials.email,
        credentials.password,
        {
          first_name: credentials.firstName,
          last_name: credentials.lastName,
          organization_id: credentials.organizationId,
        }
      );
      
      if (session) {
        setSession({
          user: user as unknown as User,
          accessToken: session.access_token,
          refreshToken: session.refresh_token,
          expiresAt: session.expires_at,
        });
      }
      
      const userData = await getCurrentUser();
      setUser(userData);
      
      return userData;
    },
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      await signOut();
      await logout();
      queryClient.clear();
    },
  });

  // Reset password mutation
  const resetPasswordMutation = useMutation({
    mutationFn: resetPassword,
  });

  // Biometric authentication
  const authenticateWithBiometric = useCallback(async (): Promise<boolean> => {
    if (!ENABLE_BIOMETRIC_AUTH) return false;

    try {
      // Check if biometric is available
      const isAvailable = await LocalAuthentication.hasHardwareAsync();
      if (!isAvailable) return false;

      const isEnrolled = await LocalAuthentication.isEnrolledAsync();
      if (!isEnrolled) return false;

      // Authenticate
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Authenticate to access Autopilot',
        fallbackLabel: 'Use passcode',
        disableDeviceFallback: false,
      });

      if (result.success) {
        // Retrieve stored credentials (you should store these securely after first login)
        const storedEmail = await SecureStore.getItemAsync('biometric_email');
        const storedPassword = await SecureStore.getItemAsync('biometric_password');

        if (storedEmail && storedPassword) {
          await loginMutation.mutateAsync({ email: storedEmail, password: storedPassword });
          return true;
        }
      }

      return false;
    } catch (error) {
      console.error('Biometric authentication error:', error);
      return false;
    }
  }, [loginMutation]);

  // Enable biometric authentication
  const enableBiometric = useCallback(async (email: string, password: string) => {
    try {
      await SecureStore.setItemAsync('biometric_email', email);
      await SecureStore.setItemAsync('biometric_password', password);
      setBiometricEnabled(true);
      return true;
    } catch (error) {
      console.error('Enable biometric error:', error);
      return false;
    }
  }, [setBiometricEnabled]);

  // Disable biometric authentication
  const disableBiometric = useCallback(async () => {
    try {
      await SecureStore.deleteItemAsync('biometric_email');
      await SecureStore.deleteItemAsync('biometric_password');
      setBiometricEnabled(false);
      return true;
    } catch (error) {
      console.error('Disable biometric error:', error);
      return false;
    }
  }, [setBiometricEnabled]);

  return {
    // State
    user,
    isAuthenticated,
    isLoading,
    isBiometricEnabled,
    
    // Mutations
    login: loginMutation.mutateAsync,
    register: registerMutation.mutateAsync,
    logout: logoutMutation.mutateAsync,
    resetPassword: resetPasswordMutation.mutateAsync,
    
    // Loading states
    isLoginLoading: loginMutation.isPending,
    isRegisterLoading: registerMutation.isPending,
    isLogoutLoading: logoutMutation.isPending,
    isResetPasswordLoading: resetPasswordMutation.isPending,
    
    // Errors
    loginError: loginMutation.error,
    registerError: registerMutation.error,
    
    // Biometric
    authenticateWithBiometric,
    enableBiometric,
    disableBiometric,
  };
};

// Hook to check if user has specific role
export const useHasRole = (...allowedRoles: string[]) => {
  const user = useAuthStore((state) => state.user);
  return user ? allowedRoles.includes(user.role) : false;
};

// Hook to get user permissions
export const usePermissions = () => {
  const user = useAuthStore((state) => state.user);
  
  const permissions = {
    canCreateTickets: ['master_admin', 'org_admin', 'property_admin', 'property_manager', 'mst', 'client'].includes(user?.role || ''),
    canAssignTickets: ['master_admin', 'org_admin', 'property_admin', 'property_manager'].includes(user?.role || ''),
    canManageUsers: ['master_admin', 'org_admin', 'property_admin'].includes(user?.role || ''),
    canManageProperties: ['master_admin', 'org_admin'].includes(user?.role || ''),
    canViewAnalytics: ['master_admin', 'org_admin', 'property_admin', 'property_manager'].includes(user?.role || ''),
    canManageInventory: ['master_admin', 'org_admin', 'property_admin', 'property_manager', 'mst'].includes(user?.role || ''),
    canManageVisitors: ['master_admin', 'org_admin', 'property_admin', 'property_manager', 'mst'].includes(user?.role || ''),
    isAdmin: ['master_admin', 'org_admin', 'property_admin'].includes(user?.role || ''),
  };
  
  return permissions;
};

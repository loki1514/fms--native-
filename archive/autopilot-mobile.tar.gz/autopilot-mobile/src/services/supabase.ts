import { createClient } from '@supabase/supabase-js';
import * as SecureStore from 'expo-secure-store';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from '@constants';
import type { User, AuthSession } from '@types';

// Custom storage adapter for React Native
const ExpoSecureStoreAdapter = {
  getItem: async (key: string): Promise<string | null> => {
    try {
      return await SecureStore.getItemAsync(key);
    } catch (error) {
      console.error('SecureStore getItem error:', error);
      return null;
    }
  },
  setItem: async (key: string, value: string): Promise<void> => {
    try {
      await SecureStore.setItemAsync(key, value);
    } catch (error) {
      console.error('SecureStore setItem error:', error);
    }
  },
  removeItem: async (key: string): Promise<void> => {
    try {
      await SecureStore.deleteItemAsync(key);
    } catch (error) {
      console.error('SecureStore removeItem error:', error);
    }
  },
};

// Initialize Supabase client
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: ExpoSecureStoreAdapter,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Auth helpers
export const signInWithEmail = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  
  if (error) throw error;
  return data;
};

export const signUpWithEmail = async (email: string, password: string, metadata?: Record<string, any>) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: metadata,
    },
  });
  
  if (error) throw error;
  return data;
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};

export const resetPassword = async (email: string) => {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: 'autopilot://reset-password',
  });
  if (error) throw error;
};

export const updatePassword = async (newPassword: string) => {
  const { error } = await supabase.auth.updateUser({
    password: newPassword,
  });
  if (error) throw error;
};

export const getCurrentUser = async (): Promise<User | null> => {
  const { data: { user }, error } = await supabase.auth.getUser();
  
  if (error || !user) return null;
  
  // Fetch additional user data from your users table
  const { data: userData, error: userError } = await supabase
    .from('users')
    .select('*')
    .eq('id', user.id)
    .single();
  
  if (userError) {
    console.error('Error fetching user data:', userError);
    return null;
  }
  
  return userData as User;
};

export const getSession = async (): Promise<AuthSession | null> => {
  const { data: { session }, error } = await supabase.auth.getSession();
  
  if (error || !session) return null;
  
  return {
    user: session.user as unknown as User,
    accessToken: session.access_token,
    refreshToken: session.refresh_token,
    expiresAt: session.expires_at,
  };
};

// Database helpers
export const fetchTickets = async (options?: {
  propertyId?: string;
  status?: string;
  priority?: string;
  assignedTo?: string;
  page?: number;
  pageSize?: number;
}) => {
  let query = supabase
    .from('tickets')
    .select('*', { count: 'exact' });
  
  if (options?.propertyId) {
    query = query.eq('property_id', options.propertyId);
  }
  
  if (options?.status) {
    query = query.eq('status', options.status);
  }
  
  if (options?.priority) {
    query = query.eq('priority', options.priority);
  }
  
  if (options?.assignedTo) {
    query = query.eq('assigned_to', options.assignedTo);
  }
  
  const page = options?.page || 1;
  const pageSize = options?.pageSize || 20;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;
  
  query = query.range(from, to).order('created_at', { ascending: false });
  
  const { data, error, count } = await query;
  
  if (error) throw error;
  
  return {
    data: data || [],
    total: count || 0,
    page,
    pageSize,
    hasMore: (count || 0) > to + 1,
  };
};

export const fetchVisitors = async (options?: {
  propertyId?: string;
  status?: string;
  date?: string;
  page?: number;
  pageSize?: number;
}) => {
  let query = supabase
    .from('visitors')
    .select('*', { count: 'exact' });
  
  if (options?.propertyId) {
    query = query.eq('property_id', options.propertyId);
  }
  
  if (options?.status) {
    query = query.eq('status', options.status);
  }
  
  if (options?.date) {
    query = query.gte('check_in_time', options.date);
  }
  
  const page = options?.page || 1;
  const pageSize = options?.pageSize || 20;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;
  
  query = query.range(from, to).order('check_in_time', { ascending: false });
  
  const { data, error, count } = await query;
  
  if (error) throw error;
  
  return {
    data: data || [],
    total: count || 0,
    page,
    pageSize,
    hasMore: (count || 0) > to + 1,
  };
};

export const fetchInventory = async (options?: {
  propertyId?: string;
  category?: string;
  lowStock?: boolean;
  page?: number;
  pageSize?: number;
}) => {
  let query = supabase
    .from('inventory')
    .select('*', { count: 'exact' });
  
  if (options?.propertyId) {
    query = query.eq('property_id', options.propertyId);
  }
  
  if (options?.category) {
    query = query.eq('category', options.category);
  }
  
  if (options?.lowStock) {
    query = query.lte('quantity', supabase.raw('min_quantity'));
  }
  
  const page = options?.page || 1;
  const pageSize = options?.pageSize || 20;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;
  
  query = query.range(from, to).order('name');
  
  const { data, error, count } = await query;
  
  if (error) throw error;
  
  return {
    data: data || [],
    total: count || 0,
    page,
    pageSize,
    hasMore: (count || 0) > to + 1,
  };
};

// Real-time subscriptions
export const subscribeToTickets = (callback: (payload: any) => void) => {
  return supabase
    .channel('tickets')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'tickets' }, callback)
    .subscribe();
};

export const subscribeToVisitors = (callback: (payload: any) => void) => {
  return supabase
    .channel('visitors')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'visitors' }, callback)
    .subscribe();
};

export const subscribeToNotifications = (userId: string, callback: (payload: any) => void) => {
  return supabase
    .channel('notifications')
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${userId}` },
      callback
    )
    .subscribe();
};

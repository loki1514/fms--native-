import { Stack } from 'expo-router';
import { useAuthStore } from '@store/authStore';
import { Redirect } from 'expo-router';

export default function AppLayout() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const isLoading = useAuthStore((state) => state.isLoading);

  // Show loading or redirect if not authenticated
  if (isLoading) {
    return null; // Or return a loading screen
  }

  if (!isAuthenticated) {
    return <Redirect href="/(auth)/login" />;
  }

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        animation: 'slide_from_right',
      }}
    >
      <Stack.Screen name="(tabs)" />
      <Stack.Screen 
        name="ticket/[id]" 
        options={{ 
          headerShown: true,
          title: 'Ticket Details',
          presentation: 'modal',
        }} 
      />
      <Stack.Screen 
        name="visitor/[id]" 
        options={{ 
          headerShown: true,
          title: 'Visitor Details',
          presentation: 'modal',
        }} 
      />
      <Stack.Screen 
        name="inventory/[id]" 
        options={{ 
          headerShown: true,
          title: 'Inventory Item',
          presentation: 'modal',
        }} 
      />
      <Stack.Screen 
        name="booking/[id]" 
        options={{ 
          headerShown: true,
          title: 'Booking Details',
          presentation: 'modal',
        }} 
      />
      <Stack.Screen 
        name="profile" 
        options={{ 
          headerShown: true,
          title: 'Profile',
          presentation: 'modal',
        }} 
      />
      <Stack.Screen 
        name="settings" 
        options={{ 
          headerShown: true,
          title: 'Settings',
          presentation: 'modal',
        }} 
      />
    </Stack>
  );
}

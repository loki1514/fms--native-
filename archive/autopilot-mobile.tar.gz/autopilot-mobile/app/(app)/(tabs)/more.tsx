import { useRouter } from 'expo-router';
import {
  YStack,
  XStack,
  Text,
  Card,
  Button,
  ListItem,
  Separator,
} from 'tamagui';
import {
  User,
  Settings,
  Calendar,
  FileText,
  Bell,
  Shield,
  HelpCircle,
  LogOut,
  ChevronRight,
  Moon,
  Building,
} from '@tamagui/lucide-icons';
import { useAuth } from '@hooks/useAuth';
import { useAuthStore } from '@store/authStore';
import { useThemeStore } from '@store/themeStore';
import { useNotificationStore } from '@store/notificationStore';

// Menu Item Component
interface MenuItemProps {
  icon: React.ElementType;
  title: string;
  subtitle?: string;
  onPress: () => void;
  showArrow?: boolean;
  destructive?: boolean;
}

const MenuItem = ({ 
  icon: Icon, 
  title, 
  subtitle, 
  onPress, 
  showArrow = true,
  destructive = false 
}: MenuItemProps) => (
  <ListItem
    hoverTheme
    pressTheme
    padding="$4"
    icon={<Icon size={22} color={destructive ? '#ef4444' : '$color'} />}
    onPress={onPress}
    title={
      <Text color={destructive ? '$danger' : '$color'} fontSize={16}>
        {title}
      </Text>
    }
    subTitle={subtitle}
    iconAfter={showArrow ? ChevronRight : undefined}
  />
);

// Section Component
interface SectionProps {
  title: string;
  children: React.ReactNode;
}

const Section = ({ title, children }: SectionProps) => (
  <YStack space="$2" marginTop="$4">
    <Text fontSize={14} color="$colorFocus" fontWeight="500" marginLeft="$4">
      {title}
    </Text>
    <Card>
      {children}
    </Card>
  </YStack>
);

export default function MoreScreen() {
  const router = useRouter();
  const { logout } = useAuth();
  const user = useAuthStore((state) => state.user);
  const theme = useThemeStore((state) => state.theme);
  const toggleTheme = useThemeStore((state) => state.toggleTheme);
  const unreadCount = useNotificationStore((state) => state.unreadCount);

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <YStack flex={1} backgroundColor="$background">
      {/* Header */}
      <YStack padding="$4" backgroundColor="$background">
        <Text fontSize={24} fontWeight="bold" color="$color">
          More
        </Text>
      </YStack>

      {/* Profile Card */}
      <Card margin="$4" marginTop="$0">
        <XStack padding="$4" space="$3" alignItems="center">
          <YStack
            width={60}
            height={60}
            borderRadius={30}
            backgroundColor="$primary"
            alignItems="center"
            justifyContent="center"
          >
            <Text color="white" fontSize={24} fontWeight="bold">
              {user?.firstName?.[0] || user?.email?.[0] || 'U'}
            </Text>
          </YStack>
          <YStack flex={1}>
            <Text fontSize={18} fontWeight="600" color="$color">
              {user?.firstName} {user?.lastName}
            </Text>
            <Text fontSize={14} color="$colorFocus">
              {user?.email}
            </Text>
            <Text fontSize={12} color="$primary" marginTop="$1">
              {user?.role.replace('_', ' ').toUpperCase()}
            </Text>
          </YStack>
          <Button
            size="$3"
            circular
            variant="outlined"
            borderColor="$borderColor"
            icon={ChevronRight}
            onPress={() => router.push('/(app)/profile')}
          />
        </XStack>
      </Card>

      <YStack paddingHorizontal="$4">
        {/* Main Features */}
        <Section title="FEATURES">
          <MenuItem
            icon={Calendar}
            title="Meeting Rooms"
            subtitle="Book and manage rooms"
            onPress={() => router.push('/(app)/meeting-rooms')}
          />
          <Separator />
          <MenuItem
            icon={FileText}
            title="SOPs & Documents"
            subtitle="Standard operating procedures"
            onPress={() => router.push('/(app)/sops')}
          />
          <Separator />
          <MenuItem
            icon={Building}
            title="Properties"
            subtitle="Manage your properties"
            onPress={() => router.push('/(app)/properties')}
          />
        </Section>

        {/* Preferences */}
        <Section title="PREFERENCES">
          <MenuItem
            icon={Bell}
            title="Notifications"
            subtitle={unreadCount > 0 ? `${unreadCount} unread` : 'Manage notifications'}
            onPress={() => router.push('/(app)/notifications')}
          />
          <Separator />
          <MenuItem
            icon={Moon}
            title="Dark Mode"
            subtitle={theme === 'system' ? 'System default' : theme === 'dark' ? 'On' : 'Off'}
            onPress={toggleTheme}
            showArrow={false}
          />
          <Separator />
          <MenuItem
            icon={Settings}
            title="Settings"
            subtitle="App preferences"
            onPress={() => router.push('/(app)/settings')}
          />
        </Section>

        {/* Support */}
        <Section title="SUPPORT">
          <MenuItem
            icon={HelpCircle}
            title="Help & Support"
            subtitle="FAQs and contact"
            onPress={() => router.push('/(app)/support')}
          />
          <Separator />
          <MenuItem
            icon={Shield}
            title="Privacy & Security"
            subtitle="Privacy policy and terms"
            onPress={() => router.push('/(app)/privacy')}
          />
        </Section>

        {/* Logout */}
        <YStack marginTop="$4">
          <Card>
            <MenuItem
              icon={LogOut}
              title="Logout"
              onPress={handleLogout}
              destructive
              showArrow={false}
            />
          </Card>
        </YStack>

        {/* App Version */}
        <YStack alignItems="center" marginTop="$6" marginBottom="$4">
          <Text fontSize={12} color="$colorFocus">
            Autopilot v1.0.0
          </Text>
          <Text fontSize={12} color="$colorFocus" marginTop="$1">
            © 2024 Autopilot Offices
          </Text>
        </YStack>
      </YStack>
    </YStack>
  );
}

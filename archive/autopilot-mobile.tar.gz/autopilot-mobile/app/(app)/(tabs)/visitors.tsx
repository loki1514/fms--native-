import { useState, useCallback } from 'react';
import { FlatList, RefreshControl } from 'react-native';
import { useRouter } from 'expo-router';
import {
  YStack,
  XStack,
  Text,
  Card,
  Button,
  Input,
  Spinner,
  Stack as TamaguiStack,
} from 'tamagui';
import {
  Search,
  Plus,
  Filter,
  User,
  LogIn,
  LogOut,
  Clock,
  Phone,
  Building,
} from '@tamagui/lucide-icons';
import { useInfiniteVisitors, useCheckInVisitor, useCheckOutVisitor } from '@hooks/useData';
import { useAuthStore } from '@store/authStore';
import { formatRelativeTime, getStatusColor } from '@utils/helpers';
import { Visitor as VisitorType, VisitorStatus } from '@types';
import { VISITOR_STATUSES } from '@constants';

// Visitor Card Component
interface VisitorCardProps {
  visitor: VisitorType;
  onPress: () => void;
  onCheckIn: () => void;
  onCheckOut: () => void;
}

const VisitorCard = ({ visitor, onPress, onCheckIn, onCheckOut }: VisitorCardProps) => {
  const statusColor = getStatusColor(visitor.status);
  const isCheckedIn = visitor.status === 'checked_in';
  const isCheckedOut = visitor.status === 'checked_out';

  return (
    <Card
      marginBottom="$3"
      pressStyle={{ scale: 0.98 }}
      onPress={onPress}
      animation="quick"
    >
      <YStack padding="$4" space="$3">
        <XStack justifyContent="space-between" alignItems="flex-start">
          <YStack flex={1} marginRight="$2">
            <Text fontSize={16} fontWeight="600" color="$color">
              {visitor.name}
            </Text>
            <XStack space="$2" alignItems="center" marginTop="$1">
              <Building size={14} color="$colorFocus" />
              <Text fontSize={14} color="$colorFocus">
                {visitor.company || 'No company'}
              </Text>
            </XStack>
            <XStack space="$2" alignItems="center" marginTop="$1">
              <Phone size={14} color="$colorFocus" />
              <Text fontSize={14} color="$colorFocus">
                {visitor.phone}
              </Text>
            </XStack>
          </YStack>
          <TamaguiStack
            paddingHorizontal="$2"
            paddingVertical="$1"
            borderRadius="$2"
            backgroundColor={hexToRgba(statusColor, 0.1)}
          >
            <Text fontSize={12} color={statusColor} fontWeight="500">
              {visitor.status.replace('_', ' ')}
            </Text>
          </TamaguiStack>
        </XStack>

        <XStack justifyContent="space-between" alignItems="center">
          <YStack>
            <Text fontSize={12} color="$colorFocus">
              Purpose: {visitor.purpose}
            </Text>
            <Text fontSize={12} color="$colorFocus">
              Host: {visitor.hostName}
            </Text>
          </YStack>
          
          {!isCheckedOut && (
            <Button
              size="$2"
              backgroundColor={isCheckedIn ? '$warning' : '$success'}
              color="white"
              icon={isCheckedIn ? LogOut : LogIn}
              onPress={(e) => {
                e.stopPropagation();
                isCheckedIn ? onCheckOut() : onCheckIn();
              }}
            >
              {isCheckedIn ? 'Check Out' : 'Check In'}
            </Button>
          )}
        </XStack>

        <Text fontSize={12} color="$colorFocus">
          {visitor.checkInTime
            ? `Checked in: ${formatRelativeTime(visitor.checkInTime)}`
            : `Expected: ${formatRelativeTime(visitor.checkInTime)}`}
        </Text>
      </YStack>
    </Card>
  );
};

// Helper function for hex to rgba
const hexToRgba = (hex: string, alpha: number): string => {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
};

// Filter Chip Component
interface FilterChipProps {
  label: string;
  isActive: boolean;
  onPress: () => void;
}

const FilterChip = ({ label, isActive, onPress }: FilterChipProps) => (
  <Button
    size="$2"
    borderRadius="$4"
    backgroundColor={isActive ? '$primary' : '$backgroundStrong'}
    color={isActive ? 'white' : '$color'}
    onPress={onPress}
    marginRight="$2"
    marginBottom="$2"
  >
    {label}
  </Button>
);

export default function VisitorsScreen() {
  const router = useRouter();
  const user = useAuthStore((state) => state.user);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<VisitorStatus | null>(null);

  // Fetch visitors
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
    refetch,
    isRefetching,
  } = useInfiniteVisitors({
    propertyId: user?.propertyId,
    status: statusFilter || undefined,
  });

  const checkInMutation = useCheckInVisitor();
  const checkOutMutation = useCheckOutVisitor();

  // Flatten pages
  const visitors = data?.pages.flatMap((page) => page.data) || [];

  // Filter by search query
  const filteredVisitors = searchQuery
    ? visitors.filter(
        (visitor) =>
          visitor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          visitor.phone.includes(searchQuery) ||
          visitor.company?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : visitors;

  const onRefresh = useCallback(() => {
    refetch();
  }, [refetch]);

  const loadMore = () => {
    if (hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  };

  const handleVisitorPress = (visitorId: string) => {
    router.push(`/(app)/visitor/${visitorId}`);
  };

  const handleCheckIn = async (visitorId: string) => {
    try {
      await checkInMutation.mutateAsync(visitorId);
    } catch (error) {
      console.error('Check-in error:', error);
    }
  };

  const handleCheckOut = async (visitorId: string) => {
    try {
      await checkOutMutation.mutateAsync(visitorId);
    } catch (error) {
      console.error('Check-out error:', error);
    }
  };

  const renderVisitor = ({ item }: { item: VisitorType }) => (
    <VisitorCard
      visitor={item}
      onPress={() => handleVisitorPress(item.id)}
      onCheckIn={() => handleCheckIn(item.id)}
      onCheckOut={() => handleCheckOut(item.id)}
    />
  );

  return (
    <YStack flex={1} backgroundColor="$background">
      {/* Header */}
      <YStack padding="$4" space="$3" backgroundColor="$background">
        <XStack justifyContent="space-between" alignItems="center">
          <Text fontSize={24} fontWeight="bold" color="$color">
            Visitors
          </Text>
          <Button
            size="$3"
            circular
            backgroundColor="$primary"
            color="white"
            icon={Plus}
            onPress={() => router.push('/(app)/visitors/new')}
          />
        </XStack>

        {/* Search Bar */}
        <XStack space="$2" alignItems="center">
          <XStack
            flex={1}
            alignItems="center"
            backgroundColor="$backgroundStrong"
            borderRadius="$3"
            paddingHorizontal="$3"
            height={44}
          >
            <Search size={18} color="$colorFocus" />
            <Input
              flex={1}
              marginLeft="$2"
              placeholder="Search visitors..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              borderWidth={0}
              backgroundColor="transparent"
              color="$color"
              fontSize={14}
            />
          </XStack>
        </XStack>

        {/* Status Filters */}
        <XStack flexWrap="wrap">
          <FilterChip
            label="All"
            isActive={statusFilter === null}
            onPress={() => setStatusFilter(null)}
          />
          {VISITOR_STATUSES.map((status) => (
            <FilterChip
              key={status.value}
              label={status.label}
              isActive={statusFilter === status.value}
              onPress={() =>
                setStatusFilter(
                  statusFilter === status.value ? null : (status.value as VisitorStatus)
                )
              }
            />
          ))}
        </XStack>
      </YStack>

      {/* Visitors List */}
      {isLoading ? (
        <YStack flex={1} alignItems="center" justifyContent="center">
          <Spinner size="large" color="$primary" />
        </YStack>
      ) : filteredVisitors.length === 0 ? (
        <YStack flex={1} alignItems="center" justifyContent="center" padding="$4">
          <User size={64} color="$colorFocus" />
          <Text fontSize={18} fontWeight="600" color="$color" marginTop="$4">
            No visitors found
          </Text>
          <Text color="$colorFocus" textAlign="center" marginTop="$2">
            {searchQuery || statusFilter
              ? 'Try adjusting your filters'
              : 'Add your first visitor to get started'}
          </Text>
          {!searchQuery && !statusFilter && (
            <Button
              marginTop="$4"
              backgroundColor="$primary"
              color="white"
              icon={Plus}
              onPress={() => router.push('/(app)/visitors/new')}
            >
              Add Visitor
            </Button>
          )}
        </YStack>
      ) : (
        <FlatList
          data={filteredVisitors}
          renderItem={renderVisitor}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16 }}
          refreshControl={
            <RefreshControl refreshing={isRefetching} onRefresh={onRefresh} />
          }
          onEndReached={loadMore}
          onEndReachedThreshold={0.5}
          ListFooterComponent={
            isFetchingNextPage ? (
              <YStack padding="$4" alignItems="center">
                <Spinner color="$primary" />
              </YStack>
            ) : null
          }
        />
      )}
    </YStack>
  );
}

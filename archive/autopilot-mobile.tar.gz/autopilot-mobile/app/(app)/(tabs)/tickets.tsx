import { useState, useCallback } from 'react';
import { FlatList, RefreshControl } from 'react-native';
import { useRouter } from 'expo-router';
import {
  YStack,
  XStack,
  Text,
  Card,
  Button,
  Input,
  Spinner,
  Stack as TamaguiStack,
  Sheet,
} from 'tamagui';
import {
  Search,
  Plus,
  Filter,
  MoreVertical,
  AlertCircle,
  Clock,
  CheckCircle,
} from '@tamagui/lucide-icons';
import { useInfiniteTickets, useUpdateTicket } from '@hooks/useData';
import { useAuthStore } from '@store/authStore';
import { formatRelativeTime, getPriorityColor, getStatusColor } from '@utils/helpers';
import { Ticket as TicketType, TicketStatus, TicketPriority } from '@types';
import { TICKET_STATUSES, TICKET_PRIORITIES } from '@constants';

// Ticket Card Component
interface TicketCardProps {
  ticket: TicketType;
  onPress: () => void;
}

const TicketCard = ({ ticket, onPress }: TicketCardProps) => {
  const priorityColor = getPriorityColor(ticket.priority);
  const statusColor = getStatusColor(ticket.status);

  return (
    <Card
      marginBottom="$3"
      pressStyle={{ scale: 0.98 }}
      onPress={onPress}
      animation="quick"
    >
      <YStack padding="$4" space="$3">
        <XStack justifyContent="space-between" alignItems="flex-start">
          <YStack flex={1} marginRight="$2">
            <Text fontSize={16} fontWeight="600" color="$color" numberOfLines={1}>
              {ticket.title}
            </Text>
            <Text fontSize={14} color="$colorFocus" numberOfLines={2} marginTop="$1">
              {ticket.description}
            </Text>
          </YStack>
          <TamaguiStack
            paddingHorizontal="$2"
            paddingVertical="$1"
            borderRadius="$2"
            backgroundColor={hexToRgba(priorityColor, 0.1)}
          >
            <Text fontSize={12} color={priorityColor} fontWeight="500">
              {ticket.priority}
            </Text>
          </TamaguiStack>
        </XStack>

        <XStack justifyContent="space-between" alignItems="center">
          <XStack space="$2" alignItems="center">
            <TamaguiStack
              width={8}
              height={8}
              borderRadius={4}
              backgroundColor={statusColor}
            />
            <Text fontSize={12} color="$colorFocus" textTransform="capitalize">
              {ticket.status.replace('_', ' ')}
            </Text>
          </XStack>
          
          <Text fontSize={12} color="$colorFocus">
            {formatRelativeTime(ticket.createdAt)}
          </Text>
        </XStack>
      </YStack>
    </Card>
  );
};

// Helper function for hex to rgba
const hexToRgba = (hex: string, alpha: number): string => {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
};

// Filter Chip Component
interface FilterChipProps {
  label: string;
  isActive: boolean;
  onPress: () => void;
}

const FilterChip = ({ label, isActive, onPress }: FilterChipProps) => (
  <Button
    size="$2"
    borderRadius="$4"
    backgroundColor={isActive ? '$primary' : '$backgroundStrong'}
    color={isActive ? 'white' : '$color'}
    onPress={onPress}
    marginRight="$2"
  >
    {label}
  </Button>
);

export default function TicketsScreen() {
  const router = useRouter();
  const user = useAuthStore((state) => state.user);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<TicketStatus | null>(null);
  const [priorityFilter, setPriorityFilter] = useState<TicketPriority | null>(null);
  const [showFilterSheet, setShowFilterSheet] = useState(false);

  // Fetch tickets
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
    refetch,
    isRefetching,
  } = useInfiniteTickets({
    propertyId: user?.propertyId,
    status: statusFilter || undefined,
    priority: priorityFilter || undefined,
  });

  const updateTicket = useUpdateTicket();

  // Flatten pages
  const tickets = data?.pages.flatMap((page) => page.data) || [];

  // Filter by search query
  const filteredTickets = searchQuery
    ? tickets.filter(
        (ticket) =>
          ticket.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          ticket.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : tickets;

  const onRefresh = useCallback(() => {
    refetch();
  }, [refetch]);

  const loadMore = () => {
    if (hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  };

  const handleTicketPress = (ticketId: string) => {
    router.push(`/(app)/ticket/${ticketId}`);
  };

  const clearFilters = () => {
    setStatusFilter(null);
    setPriorityFilter(null);
  };

  const renderTicket = ({ item }: { item: TicketType }) => (
    <TicketCard
      ticket={item}
      onPress={() => handleTicketPress(item.id)}
    />
  );

  return (
    <YStack flex={1} backgroundColor="$background">
      {/* Header */}
      <YStack padding="$4" space="$3" backgroundColor="$background">
        <XStack justifyContent="space-between" alignItems="center">
          <Text fontSize={24} fontWeight="bold" color="$color">
            Tickets
          </Text>
          <Button
            size="$3"
            circular
            backgroundColor="$primary"
            color="white"
            icon={Plus}
            onPress={() => router.push('/(app)/tickets/new')}
          />
        </XStack>

        {/* Search Bar */}
        <XStack space="$2" alignItems="center">
          <XStack
            flex={1}
            alignItems="center"
            backgroundColor="$backgroundStrong"
            borderRadius="$3"
            paddingHorizontal="$3"
            height={44}
          >
            <Search size={18} color="$colorFocus" />
            <Input
              flex={1}
              marginLeft="$2"
              placeholder="Search tickets..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              borderWidth={0}
              backgroundColor="transparent"
              color="$color"
              fontSize={14}
            />
          </XStack>
          <Button
            size="$3"
            variant={statusFilter || priorityFilter ? 'solid' : 'outlined'}
            borderColor="$borderColor"
            icon={Filter}
            onPress={() => setShowFilterSheet(true)}
          />
        </XStack>

        {/* Active Filters */}
        {(statusFilter || priorityFilter) && (
          <XStack alignItems="center">
            <Text fontSize={12} color="$colorFocus" marginRight="$2">
              Filters:
            </Text>
            {statusFilter && (
              <FilterChip
                label={statusFilter.replace('_', ' ')}
                isActive={true}
                onPress={() => setStatusFilter(null)}
              />
            )}
            {priorityFilter && (
              <FilterChip
                label={priorityFilter}
                isActive={true}
                onPress={() => setPriorityFilter(null)}
              />
            )}
            <Button size="$2" chromeless onPress={clearFilters}>
              <Text color="$danger" fontSize={12}>
                Clear
              </Text>
            </Button>
          </XStack>
        )}
      </YStack>

      {/* Tickets List */}
      {isLoading ? (
        <YStack flex={1} alignItems="center" justifyContent="center">
          <Spinner size="large" color="$primary" />
        </YStack>
      ) : filteredTickets.length === 0 ? (
        <YStack flex={1} alignItems="center" justifyContent="center" padding="$4">
          <AlertCircle size={64} color="$colorFocus" />
          <Text fontSize={18} fontWeight="600" color="$color" marginTop="$4">
            No tickets found
          </Text>
          <Text color="$colorFocus" textAlign="center" marginTop="$2">
            {searchQuery || statusFilter || priorityFilter
              ? 'Try adjusting your filters'
              : 'Create your first ticket to get started'}
          </Text>
          {!searchQuery && !statusFilter && !priorityFilter && (
            <Button
              marginTop="$4"
              backgroundColor="$primary"
              color="white"
              icon={Plus}
              onPress={() => router.push('/(app)/tickets/new')}
            >
              Create Ticket
            </Button>
          )}
        </YStack>
      ) : (
        <FlatList
          data={filteredTickets}
          renderItem={renderTicket}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16 }}
          refreshControl={
            <RefreshControl refreshing={isRefetching} onRefresh={onRefresh} />
          }
          onEndReached={loadMore}
          onEndReachedThreshold={0.5}
          ListFooterComponent={
            isFetchingNextPage ? (
              <YStack padding="$4" alignItems="center">
                <Spinner color="$primary" />
              </YStack>
            ) : null
          }
        />
      )}

      {/* Filter Sheet */}
      <Sheet
        modal
        open={showFilterSheet}
        onOpenChange={setShowFilterSheet}
        snapPoints={[50]}
        dismissOnSnapToBottom
      >
        <Sheet.Overlay />
        <Sheet.Frame padding="$4">
          <Sheet.Handle />
          <YStack space="$4">
            <Text fontSize={18} fontWeight="600">
              Filter Tickets
            </Text>

            {/* Status Filter */}
            <YStack space="$2">
              <Text fontSize={14} color="$colorFocus">
                Status
              </Text>
              <XStack flexWrap="wrap">
                {TICKET_STATUSES.map((status) => (
                  <FilterChip
                    key={status.value}
                    label={status.label}
                    isActive={statusFilter === status.value}
                    onPress={() =>
                      setStatusFilter(
                        statusFilter === status.value ? null : (status.value as TicketStatus)
                      )
                    }
                  />
                ))}
              </XStack>
            </YStack>

            {/* Priority Filter */}
            <YStack space="$2">
              <Text fontSize={14} color="$colorFocus">
                Priority
              </Text>
              <XStack flexWrap="wrap">
                {TICKET_PRIORITIES.map((priority) => (
                  <FilterChip
                    key={priority.value}
                    label={priority.label}
                    isActive={priorityFilter === priority.value}
                    onPress={() =>
                      setPriorityFilter(
                        priorityFilter === priority.value ? null : (priority.value as TicketPriority)
                      )
                    }
                  />
                ))}
              </XStack>
            </YStack>

            <Button
              backgroundColor="$primary"
              color="white"
              onPress={() => setShowFilterSheet(false)}
            >
              Apply Filters
            </Button>
          </YStack>
        </Sheet.Frame>
      </Sheet>
    </YStack>
  );
}

import { useCallback } from 'react';
import { ScrollView, RefreshControl } from 'react-native';
import { useRouter } from 'expo-router';
import {
  YStack,
  XStack,
  Text,
  Card,
  Button,
  Spinner,
  Stack as TamaguiStack,
} from 'tamagui';
import {
  Ticket,
  Users,
  Package,
  Calendar,
  TrendingUp,
  ArrowRight,
  Bell,
} from '@tamagui/lucide-icons';
import { useAuthStore } from '@store/authStore';
import { useDashboardStats } from '@hooks/useData';
import { useNotificationStore } from '@store/notificationStore';
import { formatNumber } from '@utils/helpers';

// Stat Card Component
interface StatCardProps {
  title: string;
  value: number;
  icon: React.ElementType;
  color: string;
  onPress?: () => void;
}

const StatCard = ({ title, value, icon: Icon, color, onPress }: StatCardProps) => (
  <Card
    flex={1}
    padding="$4"
    space="$2"
    pressStyle={{ scale: 0.98 }}
    onPress={onPress}
    animation="quick"
  >
    <XStack justifyContent="space-between" alignItems="center">
      <TamaguiStack
        width={40}
        height={40}
        borderRadius="$2"
        backgroundColor={color}
        alignItems="center"
        justifyContent="center"
      >
        <Icon size={20} color="white" />
      </TamaguiStack>
      <Text fontSize={24} fontWeight="bold" color="$color">
        {formatNumber(value)}
      </Text>
    </XStack>
    <Text fontSize={14} color="$colorFocus">
      {title}
    </Text>
  </Card>
);

// Quick Action Button
interface QuickActionProps {
  title: string;
  icon: React.ElementType;
  onPress: () => void;
}

const QuickAction = ({ title, icon: Icon, onPress }: QuickActionProps) => (
  <Button
    flex={1}
    height={80}
    flexDirection="column"
    space="$2"
    variant="outlined"
    borderColor="$borderColor"
    onPress={onPress}
  >
    <Icon size={24} color="$primary" />
    <Text fontSize={12} color="$color" textAlign="center">
      {title}
    </Text>
  </Button>
);

export default function DashboardScreen() {
  const router = useRouter();
  const user = useAuthStore((state) => state.user);
  const unreadCount = useNotificationStore((state) => state.unreadCount);
  
  // Fetch dashboard stats
  const { 
    data: stats, 
    isLoading, 
    refetch,
    isRefetching,
  } = useDashboardStats(user?.propertyId);

  const onRefresh = useCallback(() => {
    refetch();
  }, [refetch]);

  return (
    <YStack flex={1} backgroundColor="$background">
      {/* Header */}
      <XStack
        padding="$4"
        justifyContent="space-between"
        alignItems="center"
        backgroundColor="$background"
      >
        <YStack>
          <Text fontSize={14} color="$colorFocus">
            Welcome back,
          </Text>
          <Text fontSize={20} fontWeight="bold" color="$color">
            {user?.firstName || 'User'}
          </Text>
        </YStack>
        <Button
          size="$3"
          circular
          variant="outlined"
          borderColor="$borderColor"
          onPress={() => router.push('/(app)/notifications')}
        >
          <Bell size={20} color="$color" />
          {unreadCount > 0 && (
            <TamaguiStack
              position="absolute"
              top={-4}
              right={-4}
              width={18}
              height={18}
              borderRadius={9}
              backgroundColor="$danger"
              alignItems="center"
              justifyContent="center"
            >
              <Text color="white" fontSize={10} fontWeight="bold">
                {unreadCount > 9 ? '9+' : unreadCount}
              </Text>
            </TamaguiStack>
          )}
        </Button>
      </XStack>

      <ScrollView
        refreshControl={
          <RefreshControl refreshing={isRefetching} onRefresh={onRefresh} />
        }
      >
        <YStack padding="$4" space="$4">
          {/* Stats Grid */}
          {isLoading ? (
            <YStack height={200} alignItems="center" justifyContent="center">
              <Spinner size="large" color="$primary" />
            </YStack>
          ) : (
            <>
              <XStack space="$3">
                <StatCard
                  title="Open Tickets"
                  value={stats?.openTickets || 0}
                  icon={Ticket}
                  color="#3b82f6"
                  onPress={() => router.push('/(app)/(tabs)/tickets')}
                />
                <StatCard
                  title="Checked In"
                  value={stats?.checkedInVisitors || 0}
                  icon={Users}
                  color="#22c55e"
                  onPress={() => router.push('/(app)/(tabs)/visitors')}
                />
              </XStack>

              <XStack space="$3">
                <StatCard
                  title="Low Stock"
                  value={stats?.lowStockItems || 0}
                  icon={Package}
                  color="#f59e0b"
                  onPress={() => router.push('/(app)/(tabs)/inventory')}
                />
                <StatCard
                  title="Today's Bookings"
                  value={0}
                  icon={Calendar}
                  color="#8b5cf6"
                  onPress={() => router.push('/(app)/(tabs)/more')}
                />
              </XStack>
            </>
          )}

          {/* Quick Actions */}
          <YStack space="$3">
            <Text fontSize={18} fontWeight="600" color="$color">
              Quick Actions
            </Text>
            <XStack space="$3">
              <QuickAction
                title="New Ticket"
                icon={Ticket}
                onPress={() => router.push('/(app)/tickets/new')}
              />
              <QuickAction
                title="Check In"
                icon={Users}
                onPress={() => router.push('/(app)/visitors/check-in')}
              />
            </XStack>
            <XStack space="$3">
              <QuickAction
                title="Scan QR"
                icon={Package}
                onPress={() => router.push('/(app)/inventory/scan')}
              />
              <QuickAction
                title="Book Room"
                icon={Calendar}
                onPress={() => router.push('/(app)/bookings/new')}
              />
            </XStack>
          </YStack>

          {/* Recent Activity */}
          <YStack space="$3">
            <XStack justifyContent="space-between" alignItems="center">
              <Text fontSize={18} fontWeight="600" color="$color">
                Recent Activity
              </Text>
              <Button
                size="$2"
                chromeless
                iconAfter={ArrowRight}
                onPress={() => router.push('/(app)/activity')}
              >
                View All
              </Button>
            </XStack>
            
            <Card padding="$4">
              <YStack space="$3" alignItems="center">
                <TrendingUp size={48} color="$colorFocus" />
                <Text color="$colorFocus" textAlign="center">
                  No recent activity to display
                </Text>
              </YStack>
            </Card>
          </YStack>
        </YStack>
      </ScrollView>
    </YStack>
  );
}

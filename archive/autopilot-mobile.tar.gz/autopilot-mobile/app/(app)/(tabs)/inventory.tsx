import { useState, useCallback } from 'react';
import { FlatList, RefreshControl } from 'react-native';
import { useRouter } from 'expo-router';
import {
  YStack,
  XStack,
  Text,
  Card,
  Button,
  Input,
  Spinner,
  Stack as TamaguiStack,
} from 'tamagui';
import {
  Search,
  Plus,
  Package,
  AlertTriangle,
  QrCode,
  ArrowUp,
  ArrowDown,
} from '@tamagui/lucide-icons';
import { useInfiniteInventory, useUpdateStock } from '@hooks/useData';
import { useAuthStore } from '@store/authStore';
import { formatNumber } from '@utils/helpers';
import { InventoryItem as InventoryItemType } from '@types';

// Inventory Card Component
interface InventoryCardProps {
  item: InventoryItemType;
  onPress: () => void;
}

const InventoryCard = ({ item, onPress }: InventoryCardProps) => {
  const isLowStock = item.quantity <= item.minQuantity;

  return (
    <Card
      marginBottom="$3"
      pressStyle={{ scale: 0.98 }}
      onPress={onPress}
      animation="quick"
    >
      <YStack padding="$4" space="$3">
        <XStack justifyContent="space-between" alignItems="flex-start">
          <YStack flex={1} marginRight="$2">
            <Text fontSize={16} fontWeight="600" color="$color">
              {item.name}
            </Text>
            <Text fontSize={14} color="$colorFocus" marginTop="$1">
              SKU: {item.sku}
            </Text>
            <Text fontSize={12} color="$colorFocus" marginTop="$1">
              Category: {item.category}
            </Text>
          </YStack>
          {isLowStock && (
            <TamaguiStack
              paddingHorizontal="$2"
              paddingVertical="$1"
              borderRadius="$2"
              backgroundColor="rgba(239, 68, 68, 0.1)"
              flexDirection="row"
              alignItems="center"
              space="$1"
            >
              <AlertTriangle size={12} color="#ef4444" />
              <Text fontSize={12} color="#ef4444" fontWeight="500">
                Low Stock
              </Text>
            </TamaguiStack>
          )}
        </XStack>

        <XStack justifyContent="space-between" alignItems="center">
          <YStack>
            <Text fontSize={12} color="$colorFocus">
              Location: {item.location}
            </Text>
            <Text fontSize={12} color="$colorFocus">
              Unit: {item.unit}
            </Text>
          </YStack>
          
          <XStack space="$2" alignItems="center">
            <TamaguiStack
              paddingHorizontal="$3"
              paddingVertical="$1"
              borderRadius="$2"
              backgroundColor={isLowStock ? 'rgba(239, 68, 68, 0.1)' : 'rgba(34, 197, 94, 0.1)'}
            >
              <Text
                fontSize={16}
                fontWeight="bold"
                color={isLowStock ? '#ef4444' : '#22c55e'}
              >
                {formatNumber(item.quantity)}
              </Text>
            </TamaguiStack>
            <Text fontSize={12} color="$colorFocus">
              / {formatNumber(item.minQuantity)} min
            </Text>
          </XStack>
        </XStack>
      </YStack>
    </Card>
  );
};

export default function InventoryScreen() {
  const router = useRouter();
  const user = useAuthStore((state) => state.user);
  const [searchQuery, setSearchQuery] = useState('');
  const [showLowStockOnly, setShowLowStockOnly] = useState(false);

  // Fetch inventory
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
    refetch,
    isRefetching,
  } = useInfiniteInventory({
    propertyId: user?.propertyId,
    lowStock: showLowStockOnly || undefined,
  });

  const updateStock = useUpdateStock();

  // Flatten pages
  const inventory = data?.pages.flatMap((page) => page.data) || [];

  // Filter by search query
  const filteredInventory = searchQuery
    ? inventory.filter(
        (item) =>
          item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.category.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : inventory;

  const onRefresh = useCallback(() => {
    refetch();
  }, [refetch]);

  const loadMore = () => {
    if (hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  };

  const handleItemPress = (itemId: string) => {
    router.push(`/(app)/inventory/${itemId}`);
  };

  const handleScanQR = () => {
    router.push('/(app)/inventory/scan');
  };

  const renderItem = ({ item }: { item: InventoryItemType }) => (
    <InventoryCard item={item} onPress={() => handleItemPress(item.id)} />
  );

  return (
    <YStack flex={1} backgroundColor="$background">
      {/* Header */}
      <YStack padding="$4" space="$3" backgroundColor="$background">
        <XStack justifyContent="space-between" alignItems="center">
          <Text fontSize={24} fontWeight="bold" color="$color">
            Inventory
          </Text>
          <XStack space="$2">
            <Button
              size="$3"
              circular
              variant="outlined"
              borderColor="$borderColor"
              icon={QrCode}
              onPress={handleScanQR}
            />
            <Button
              size="$3"
              circular
              backgroundColor="$primary"
              color="white"
              icon={Plus}
              onPress={() => router.push('/(app)/inventory/new')}
            />
          </XStack>
        </XStack>

        {/* Search Bar */}
        <XStack space="$2" alignItems="center">
          <XStack
            flex={1}
            alignItems="center"
            backgroundColor="$backgroundStrong"
            borderRadius="$3"
            paddingHorizontal="$3"
            height={44}
          >
            <Search size={18} color="$colorFocus" />
            <Input
              flex={1}
              marginLeft="$2"
              placeholder="Search items..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              borderWidth={0}
              backgroundColor="transparent"
              color="$color"
              fontSize={14}
            />
          </XStack>
        </XStack>

        {/* Filter Chips */}
        <XStack space="$2">
          <Button
            size="$2"
            borderRadius="$4"
            backgroundColor={showLowStockOnly ? '$warning' : '$backgroundStrong'}
            color={showLowStockOnly ? 'white' : '$color'}
            onPress={() => setShowLowStockOnly(!showLowStockOnly)}
            icon={AlertTriangle}
          >
            Low Stock
          </Button>
        </XStack>
      </YStack>

      {/* Inventory List */}
      {isLoading ? (
        <YStack flex={1} alignItems="center" justifyContent="center">
          <Spinner size="large" color="$primary" />
        </YStack>
      ) : filteredInventory.length === 0 ? (
        <YStack flex={1} alignItems="center" justifyContent="center" padding="$4">
          <Package size={64} color="$colorFocus" />
          <Text fontSize={18} fontWeight="600" color="$color" marginTop="$4">
            No items found
          </Text>
          <Text color="$colorFocus" textAlign="center" marginTop="$2">
            {searchQuery || showLowStockOnly
              ? 'Try adjusting your filters'
              : 'Add your first inventory item to get started'}
          </Text>
          {!searchQuery && !showLowStockOnly && (
            <Button
              marginTop="$4"
              backgroundColor="$primary"
              color="white"
              icon={Plus}
              onPress={() => router.push('/(app)/inventory/new')}
            >
              Add Item
            </Button>
          )}
        </YStack>
      ) : (
        <FlatList
          data={filteredInventory}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16 }}
          refreshControl={
            <RefreshControl refreshing={isRefetching} onRefresh={onRefresh} />
          }
          onEndReached={loadMore}
          onEndReachedThreshold={0.5}
          ListFooterComponent={
            isFetchingNextPage ? (
              <YStack padding="$4" alignItems="center">
                <Spinner color="$primary" />
              </YStack>
            ) : null
          }
        />
      )}
    </YStack>
  );
}

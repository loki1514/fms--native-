import { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import {
  YStack,
  XStack,
  Text,
  Button,
  Input,
  Label,
  Spinner,
} from 'tamagui';
import { Mail, ArrowLeft, CheckCircle } from '@tamagui/lucide-icons';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '@hooks/useAuth';
import { ERROR_MESSAGES } from '@constants';

// Validation schema
const forgotPasswordSchema = z.object({
  email: z.string().email(ERROR_MESSAGES.INVALID_EMAIL),
});

type ForgotPasswordFormData = z.infer<typeof forgotPasswordSchema>;

export default function ForgotPasswordScreen() {
  const router = useRouter();
  const [isSuccess, setIsSuccess] = useState(false);
  
  const { resetPassword, isResetPasswordLoading } = useAuth();

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<ForgotPasswordFormData>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
      email: '',
    },
  });

  const onSubmit = async (data: ForgotPasswordFormData) => {
    try {
      await resetPassword(data.email);
      setIsSuccess(true);
    } catch (error) {
      // Error is handled by the mutation
    }
  };

  if (isSuccess) {
    return (
      <YStack
        flex={1}
        padding="$4"
        space="$4"
        justifyContent="center"
        alignItems="center"
        backgroundColor="$background"
      >
        <CheckCircle size={80} color="$success" />
        <Text fontSize={24} fontWeight="bold" color="$color" textAlign="center">
          Check Your Email
        </Text>
        <Text color="$colorFocus" textAlign="center" lineHeight={20}>
          We've sent a password reset link to your email address. Please check your inbox and follow the instructions to reset your password.
        </Text>
        <Button
          marginTop="$4"
          backgroundColor="$primary"
          color="white"
          onPress={() => router.push('/(auth)/login')}
        >
          Back to Login
        </Button>
      </YStack>
    );
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        keyboardShouldPersistTaps="handled"
      >
        <YStack
          flex={1}
          padding="$4"
          space="$4"
          justifyContent="center"
          backgroundColor="$background"
        >
          {/* Back Button */}
          <Button
            position="absolute"
            top="$4"
            left="$4"
            size="$3"
            chromeless
            icon={ArrowLeft}
            onPress={() => router.back()}
          >
            Back
          </Button>

          {/* Header */}
          <YStack space="$2" marginBottom="$4">
            <Text fontSize={28} fontWeight="bold" color="$color">
              Reset Password
            </Text>
            <Text fontSize={14} color="$colorFocus">
              Enter your email address and we'll send you a link to reset your password
            </Text>
          </YStack>

          {/* Form */}
          <YStack space="$4">
            <YStack space="$2">
              <Label color="$color">Email</Label>
              <Controller
                control={control}
                name="email"
                render={({ field: { onChange, value } }) => (
                  <XStack
                    alignItems="center"
                    backgroundColor="$backgroundStrong"
                    borderRadius="$3"
                    borderWidth={1}
                    borderColor={errors.email ? '$danger' : '$borderColor'}
                    paddingHorizontal="$3"
                    height={48}
                  >
                    <Mail size={20} color="$colorFocus" />
                    <Input
                      flex={1}
                      marginLeft="$2"
                      placeholder="Enter your email"
                      value={value}
                      onChangeText={onChange}
                      autoCapitalize="none"
                      keyboardType="email-address"
                      autoComplete="email"
                      borderWidth={0}
                      backgroundColor="transparent"
                      color="$color"
                    />
                  </XStack>
                )}
              />
              {errors.email && (
                <Text color="$danger" fontSize={12}>
                  {errors.email.message}
                </Text>
              )}
            </YStack>

            {/* Submit Button */}
            <Button
              size="$4"
              backgroundColor="$primary"
              color="white"
              onPress={handleSubmit(onSubmit)}
              disabled={isResetPasswordLoading}
              icon={isResetPasswordLoading ? <Spinner color="white" /> : undefined}
              marginTop="$2"
            >
              {isResetPasswordLoading ? 'Sending...' : 'Send Reset Link'}
            </Button>
          </YStack>
        </YStack>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

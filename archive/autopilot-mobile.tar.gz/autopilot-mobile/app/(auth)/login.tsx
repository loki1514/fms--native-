import { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import {
  YStack,
  XStack,
  Text,
  Button,
  Input,
  Label,
  Stack as TamaguiStack,
  Sheet,
  Spinner,
} from 'tamagui';
import { Eye, EyeOff, Mail, Lock, Fingerprint } from '@tamagui/lucide-icons';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '@hooks/useAuth';
import { useThemeStore } from '@store/themeStore';
import { ERROR_MESSAGES, SUCCESS_MESSAGES, ENABLE_BIOMETRIC_AUTH } from '@constants';

// Validation schema
const loginSchema = z.object({
  email: z.string().email(ERROR_MESSAGES.INVALID_EMAIL),
  password: z.string().min(1, ERROR_MESSAGES.REQUIRED),
});

type LoginFormData = z.infer<typeof loginSchema>;

export default function LoginScreen() {
  const router = useRouter();
  const theme = useThemeStore((state) => state.theme);
  const [showPassword, setShowPassword] = useState(false);
  const [showBiometricSheet, setShowBiometricSheet] = useState(false);
  
  const {
    login,
    isLoginLoading,
    loginError,
    isBiometricEnabled,
    authenticateWithBiometric,
    enableBiometric,
  } = useAuth();

  const {
    control,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  const email = watch('email');
  const password = watch('password');

  const onSubmit = async (data: LoginFormData) => {
    try {
      await login(data);
      
      // Ask to enable biometric after successful login
      if (ENABLE_BIOMETRIC_AUTH && !isBiometricEnabled) {
        setShowBiometricSheet(true);
      }
    } catch (error) {
      // Error is handled by the mutation
    }
  };

  const handleBiometricLogin = async () => {
    const success = await authenticateWithBiometric();
    if (!success) {
      // Biometric login failed, show manual login
    }
  };

  const handleEnableBiometric = async () => {
    await enableBiometric(email, password);
    setShowBiometricSheet(false);
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        keyboardShouldPersistTaps="handled"
      >
        <YStack
          flex={1}
          padding="$4"
          space="$4"
          justifyContent="center"
          backgroundColor="$background"
        >
          {/* Logo and Title */}
          <YStack space="$2" alignItems="center" marginBottom="$4">
            <TamaguiStack
              width={80}
              height={80}
              backgroundColor="$primary"
              borderRadius="$4"
              alignItems="center"
              justifyContent="center"
            >
              <Text color="white" fontSize={32} fontWeight="bold">
                A
              </Text>
            </TamaguiStack>
            <Text fontSize={28} fontWeight="bold" color="$color">
              Autopilot
            </Text>
            <Text fontSize={14} color="$colorFocus">
              Facility Management System
            </Text>
          </YStack>

          {/* Login Form */}
          <YStack space="$4">
            {/* Email Field */}
            <YStack space="$2">
              <Label color="$color">Email</Label>
              <Controller
                control={control}
                name="email"
                render={({ field: { onChange, value } }) => (
                  <XStack
                    alignItems="center"
                    backgroundColor="$backgroundStrong"
                    borderRadius="$3"
                    borderWidth={1}
                    borderColor={errors.email ? '$danger' : '$borderColor'}
                    paddingHorizontal="$3"
                    height={48}
                  >
                    <Mail size={20} color="$colorFocus" />
                    <Input
                      flex={1}
                      marginLeft="$2"
                      placeholder="Enter your email"
                      value={value}
                      onChangeText={onChange}
                      autoCapitalize="none"
                      keyboardType="email-address"
                      autoComplete="email"
                      borderWidth={0}
                      backgroundColor="transparent"
                      color="$color"
                    />
                  </XStack>
                )}
              />
              {errors.email && (
                <Text color="$danger" fontSize={12}>
                  {errors.email.message}
                </Text>
              )}
            </YStack>

            {/* Password Field */}
            <YStack space="$2">
              <Label color="$color">Password</Label>
              <Controller
                control={control}
                name="password"
                render={({ field: { onChange, value } }) => (
                  <XStack
                    alignItems="center"
                    backgroundColor="$backgroundStrong"
                    borderRadius="$3"
                    borderWidth={1}
                    borderColor={errors.password ? '$danger' : '$borderColor'}
                    paddingHorizontal="$3"
                    height={48}
                  >
                    <Lock size={20} color="$colorFocus" />
                    <Input
                      flex={1}
                      marginLeft="$2"
                      placeholder="Enter your password"
                      value={value}
                      onChangeText={onChange}
                      secureTextEntry={!showPassword}
                      autoComplete="password"
                      borderWidth={0}
                      backgroundColor="transparent"
                      color="$color"
                    />
                    <Button
                      size="$2"
                      chromeless
                      onPress={() => setShowPassword(!showPassword)}
                      icon={showPassword ? EyeOff : Eye}
                    />
                  </XStack>
                )}
              />
              {errors.password && (
                <Text color="$danger" fontSize={12}>
                  {errors.password.message}
                </Text>
              )}
            </YStack>

            {/* Forgot Password Link */}
            <XStack justifyContent="flex-end">
              <Button
                size="$2"
                chromeless
                onPress={() => router.push('/(auth)/forgot-password')}
              >
                <Text color="$primary" fontSize={14}>
                  Forgot Password?
                </Text>
              </Button>
            </XStack>

            {/* Error Message */}
            {loginError && (
              <Text color="$danger" textAlign="center" fontSize={14}>
                {ERROR_MESSAGES.INVALID_CREDENTIALS}
              </Text>
            )}

            {/* Login Button */}
            <Button
              size="$4"
              backgroundColor="$primary"
              color="white"
              onPress={handleSubmit(onSubmit)}
              disabled={isLoginLoading}
              icon={isLoginLoading ? <Spinner color="white" /> : undefined}
            >
              {isLoginLoading ? 'Signing In...' : 'Sign In'}
            </Button>

            {/* Biometric Login Button */}
            {ENABLE_BIOMETRIC_AUTH && isBiometricEnabled && (
              <Button
                size="$4"
                variant="outlined"
                borderColor="$primary"
                color="$primary"
                onPress={handleBiometricLogin}
                icon={Fingerprint}
              >
                Sign In with Biometrics
              </Button>
            )}
          </YStack>

          {/* Register Link */}
          <XStack justifyContent="center" space="$2" marginTop="$4">
            <Text color="$colorFocus">Don't have an account?</Text>
            <Button
              size="$2"
              chromeless
              onPress={() => router.push('/(auth)/register')}
            >
              <Text color="$primary" fontWeight="600">
                Sign Up
              </Text>
            </Button>
          </XStack>
        </YStack>

        {/* Biometric Enable Sheet */}
        <Sheet
          modal
          open={showBiometricSheet}
          onOpenChange={setShowBiometricSheet}
          snapPoints={[40]}
          dismissOnSnapToBottom
        >
          <Sheet.Overlay />
          <Sheet.Frame padding="$4" space="$4">
            <Sheet.Handle />
            <YStack space="$4" alignItems="center">
              <Fingerprint size={48} color="$primary" />
              <Text fontSize={18} fontWeight="600" textAlign="center">
                Enable Biometric Login?
              </Text>
              <Text color="$colorFocus" textAlign="center">
                Sign in faster and more securely using your biometric authentication
              </Text>
              <XStack space="$3" width="100%">
                <Button
                  flex={1}
                  variant="outlined"
                  onPress={() => setShowBiometricSheet(false)}
                >
                  Not Now
                </Button>
                <Button
                  flex={1}
                  backgroundColor="$primary"
                  color="white"
                  onPress={handleEnableBiometric}
                >
                  Enable
                </Button>
              </XStack>
            </YStack>
          </Sheet.Frame>
        </Sheet>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

import { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import {
  YStack,
  XStack,
  Text,
  Button,
  Input,
  Label,
  Spinner,
} from 'tamagui';
import { Eye, EyeOff, Mail, Lock, User, Building } from '@tamagui/lucide-icons';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '@hooks/useAuth';
import { ERROR_MESSAGES, VALIDATION } from '@constants';

// Validation schema
const registerSchema = z.object({
  firstName: z.string().min(VALIDATION.MIN_NAME_LENGTH, 'First name is required'),
  lastName: z.string().min(VALIDATION.MIN_NAME_LENGTH, 'Last name is required'),
  email: z.string().email(ERROR_MESSAGES.INVALID_EMAIL),
  password: z.string().min(VALIDATION.MIN_PASSWORD_LENGTH, ERROR_MESSAGES.MIN_PASSWORD),
  confirmPassword: z.string(),
  organizationId: z.string().optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: ERROR_MESSAGES.PASSWORD_MISMATCH,
  path: ['confirmPassword'],
});

type RegisterFormData = z.infer<typeof registerSchema>;

export default function RegisterScreen() {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  const { register, isRegisterLoading, registerError } = useAuth();

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      password: '',
      confirmPassword: '',
      organizationId: '',
    },
  });

  const onSubmit = async (data: RegisterFormData) => {
    try {
      await register({
        email: data.email,
        password: data.password,
        firstName: data.firstName,
        lastName: data.lastName,
        organizationId: data.organizationId,
      });
    } catch (error) {
      // Error is handled by the mutation
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        keyboardShouldPersistTaps="handled"
      >
        <YStack
          flex={1}
          padding="$4"
          space="$4"
          justifyContent="center"
          backgroundColor="$background"
        >
          {/* Header */}
          <YStack space="$2" marginBottom="$4">
            <Text fontSize={28} fontWeight="bold" color="$color">
              Create Account
            </Text>
            <Text fontSize={14} color="$colorFocus">
              Sign up to get started with Autopilot
            </Text>
          </YStack>

          {/* Registration Form */}
          <YStack space="$4">
            {/* Name Fields */}
            <XStack space="$3">
              <YStack flex={1} space="$2">
                <Label color="$color">First Name</Label>
                <Controller
                  control={control}
                  name="firstName"
                  render={({ field: { onChange, value } }) => (
                    <XStack
                      alignItems="center"
                      backgroundColor="$backgroundStrong"
                      borderRadius="$3"
                      borderWidth={1}
                      borderColor={errors.firstName ? '$danger' : '$borderColor'}
                      paddingHorizontal="$3"
                      height={48}
                    >
                      <User size={20} color="$colorFocus" />
                      <Input
                        flex={1}
                        marginLeft="$2"
                        placeholder="First name"
                        value={value}
                        onChangeText={onChange}
                        autoCapitalize="words"
                        borderWidth={0}
                        backgroundColor="transparent"
                        color="$color"
                      />
                    </XStack>
                  )}
                />
                {errors.firstName && (
                  <Text color="$danger" fontSize={12}>
                    {errors.firstName.message}
                  </Text>
                )}
              </YStack>

              <YStack flex={1} space="$2">
                <Label color="$color">Last Name</Label>
                <Controller
                  control={control}
                  name="lastName"
                  render={({ field: { onChange, value } }) => (
                    <XStack
                      alignItems="center"
                      backgroundColor="$backgroundStrong"
                      borderRadius="$3"
                      borderWidth={1}
                      borderColor={errors.lastName ? '$danger' : '$borderColor'}
                      paddingHorizontal="$3"
                      height={48}
                    >
                      <User size={20} color="$colorFocus" />
                      <Input
                        flex={1}
                        marginLeft="$2"
                        placeholder="Last name"
                        value={value}
                        onChangeText={onChange}
                        autoCapitalize="words"
                        borderWidth={0}
                        backgroundColor="transparent"
                        color="$color"
                      />
                    </XStack>
                  )}
                />
                {errors.lastName && (
                  <Text color="$danger" fontSize={12}>
                    {errors.lastName.message}
                  </Text>
                )}
              </YStack>
            </XStack>

            {/* Email Field */}
            <YStack space="$2">
              <Label color="$color">Email</Label>
              <Controller
                control={control}
                name="email"
                render={({ field: { onChange, value } }) => (
                  <XStack
                    alignItems="center"
                    backgroundColor="$backgroundStrong"
                    borderRadius="$3"
                    borderWidth={1}
                    borderColor={errors.email ? '$danger' : '$borderColor'}
                    paddingHorizontal="$3"
                    height={48}
                  >
                    <Mail size={20} color="$colorFocus" />
                    <Input
                      flex={1}
                      marginLeft="$2"
                      placeholder="Enter your email"
                      value={value}
                      onChangeText={onChange}
                      autoCapitalize="none"
                      keyboardType="email-address"
                      autoComplete="email"
                      borderWidth={0}
                      backgroundColor="transparent"
                      color="$color"
                    />
                  </XStack>
                )}
              />
              {errors.email && (
                <Text color="$danger" fontSize={12}>
                  {errors.email.message}
                </Text>
              )}
            </YStack>

            {/* Organization Field (Optional) */}
            <YStack space="$2">
              <Label color="$color">Organization ID (Optional)</Label>
              <Controller
                control={control}
                name="organizationId"
                render={({ field: { onChange, value } }) => (
                  <XStack
                    alignItems="center"
                    backgroundColor="$backgroundStrong"
                    borderRadius="$3"
                    borderWidth={1}
                    borderColor="$borderColor"
                    paddingHorizontal="$3"
                    height={48}
                  >
                    <Building size={20} color="$colorFocus" />
                    <Input
                      flex={1}
                      marginLeft="$2"
                      placeholder="Enter organization ID"
                      value={value}
                      onChangeText={onChange}
                      borderWidth={0}
                      backgroundColor="transparent"
                      color="$color"
                    />
                  </XStack>
                )}
              />
            </YStack>

            {/* Password Field */}
            <YStack space="$2">
              <Label color="$color">Password</Label>
              <Controller
                control={control}
                name="password"
                render={({ field: { onChange, value } }) => (
                  <XStack
                    alignItems="center"
                    backgroundColor="$backgroundStrong"
                    borderRadius="$3"
                    borderWidth={1}
                    borderColor={errors.password ? '$danger' : '$borderColor'}
                    paddingHorizontal="$3"
                    height={48}
                  >
                    <Lock size={20} color="$colorFocus" />
                    <Input
                      flex={1}
                      marginLeft="$2"
                      placeholder="Create a password"
                      value={value}
                      onChangeText={onChange}
                      secureTextEntry={!showPassword}
                      autoComplete="new-password"
                      borderWidth={0}
                      backgroundColor="transparent"
                      color="$color"
                    />
                    <Button
                      size="$2"
                      chromeless
                      onPress={() => setShowPassword(!showPassword)}
                      icon={showPassword ? EyeOff : Eye}
                    />
                  </XStack>
                )}
              />
              {errors.password && (
                <Text color="$danger" fontSize={12}>
                  {errors.password.message}
                </Text>
              )}
            </YStack>

            {/* Confirm Password Field */}
            <YStack space="$2">
              <Label color="$color">Confirm Password</Label>
              <Controller
                control={control}
                name="confirmPassword"
                render={({ field: { onChange, value } }) => (
                  <XStack
                    alignItems="center"
                    backgroundColor="$backgroundStrong"
                    borderRadius="$3"
                    borderWidth={1}
                    borderColor={errors.confirmPassword ? '$danger' : '$borderColor'}
                    paddingHorizontal="$3"
                    height={48}
                  >
                    <Lock size={20} color="$colorFocus" />
                    <Input
                      flex={1}
                      marginLeft="$2"
                      placeholder="Confirm your password"
                      value={value}
                      onChangeText={onChange}
                      secureTextEntry={!showConfirmPassword}
                      autoComplete="new-password"
                      borderWidth={0}
                      backgroundColor="transparent"
                      color="$color"
                    />
                    <Button
                      size="$2"
                      chromeless
                      onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                      icon={showConfirmPassword ? EyeOff : Eye}
                    />
                  </XStack>
                )}
              />
              {errors.confirmPassword && (
                <Text color="$danger" fontSize={12}>
                  {errors.confirmPassword.message}
                </Text>
              )}
            </YStack>

            {/* Error Message */}
            {registerError && (
              <Text color="$danger" textAlign="center" fontSize={14}>
                {registerError.message || 'Registration failed. Please try again.'}
              </Text>
            )}

            {/* Register Button */}
            <Button
              size="$4"
              backgroundColor="$primary"
              color="white"
              onPress={handleSubmit(onSubmit)}
              disabled={isRegisterLoading}
              icon={isRegisterLoading ? <Spinner color="white" /> : undefined}
              marginTop="$2"
            >
              {isRegisterLoading ? 'Creating Account...' : 'Create Account'}
            </Button>
          </YStack>

          {/* Login Link */}
          <XStack justifyContent="center" space="$2" marginTop="$4">
            <Text color="$colorFocus">Already have an account?</Text>
            <Button
              size="$2"
              chromeless
              onPress={() => router.push('/(auth)/login')}
            >
              <Text color="$primary" fontWeight="600">
                Sign In
              </Text>
            </Button>
          </XStack>
        </YStack>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

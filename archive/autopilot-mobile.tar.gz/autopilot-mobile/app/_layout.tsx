import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { TamaguiProvider, Theme } from 'tamagui';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { useColorScheme } from 'react-native';
import tamaguiConfig from '../tamagui.config';
import { useThemeStore } from '@store/themeStore';
import { useAuthStore } from '@store/authStore';
import { usePushNotifications } from '@hooks/useNotifications';
import { supabase } from '@services/supabase';

// Create Query Client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: 2,
      refetchOnWindowFocus: false,
    },
  },
});

// Root layout component
export default function RootLayout() {
  const colorScheme = useColorScheme();
  const theme = useThemeStore((state) => state.theme);
  const setLoading = useAuthStore((state) => state.setLoading);
  const setUser = useAuthStore((state) => state.setUser);
  const setSession = useAuthStore((state) => state.setSession);
  
  // Initialize push notifications
  usePushNotifications();

  // Initialize auth state
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        setLoading(true);
        
        // Check for existing session
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session) {
          setSession({
            user: session.user as any,
            accessToken: session.access_token,
            refreshToken: session.refresh_token,
            expiresAt: session.expires_at,
          });
          setUser(session.user as any);
        }
      } catch (error) {
        console.error('Auth initialization error:', error);
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN' && session) {
        setSession({
          user: session.user as any,
          accessToken: session.access_token,
          refreshToken: session.refresh_token,
          expiresAt: session.expires_at,
        });
        setUser(session.user as any);
      } else if (event === 'SIGNED_OUT') {
        setSession(null);
        setUser(null);
        queryClient.clear();
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [setUser, setSession, setLoading]);

  // Determine active theme
  const activeTheme = theme === 'system' ? colorScheme : theme;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <TamaguiProvider config={tamaguiConfig}>
          <Theme name={activeTheme}>
            <QueryClientProvider client={queryClient}>
              <Stack
                screenOptions={{
                  headerStyle: {
                    backgroundColor: activeTheme === 'dark' ? '#111827' : '#ffffff',
                  },
                  headerTintColor: activeTheme === 'dark' ? '#f9fafb' : '#111827',
                  headerTitleStyle: {
                    fontWeight: '600',
                  },
                  contentStyle: {
                    backgroundColor: activeTheme === 'dark' ? '#111827' : '#ffffff',
                  },
                }}
              >
                <Stack.Screen name="(auth)" options={{ headerShown: false }} />
                <Stack.Screen name="(app)" options={{ headerShown: false }} />
              </Stack>
              <StatusBar style={activeTheme === 'dark' ? 'light' : 'dark'} />
            </QueryClientProvider>
          </Theme>
        </TamaguiProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

# Autopilot Mobile

A React Native mobile application for the Autopilot Facility Management System, built with Expo SDK 50.

## Features

- **Authentication**: Email/password login, biometric authentication, password reset
- **Dashboard**: Real-time stats and quick actions
- **Tickets**: Create, view, and manage maintenance tickets
- **Visitor Management**: Check-in/check-out visitors, pre-registration
- **Inventory**: Track stock levels, QR code scanning
- **Meeting Rooms**: Book and manage room reservations
- **Push Notifications**: Real-time alerts and updates
- **Offline Support**: Work offline with automatic sync
- **Dark Mode**: System and manual theme switching

## Tech Stack

- **Framework**: Expo SDK 50 (Managed Workflow)
- **Navigation**: Expo Router v3 (File-based)
- **UI**: Tamagui (Cross-platform design system)
- **State Management**: Zustand + TanStack Query
- **Backend**: Supabase (Auth, Database, Realtime)
- **Storage**: SecureStore (tokens), MMKV (data)
- **Forms**: React Hook Form + Zod
- **Notifications**: Expo Notifications

## Prerequisites

- Node.js 18+ 
- npm or yarn
- Expo CLI: `npm install -g expo-cli`
- iOS: macOS with Xcode (for iOS simulator)
- Android: Android Studio (for Android emulator)

## Installation

1. **Clone and navigate to the project:**
```bash
cd autopilot-mobile
```

2. **Install dependencies:**
```bash
npm install
```

3. **Set up environment variables:**
The `.env` file is already configured with your Supabase credentials. Update if needed:
```env
EXPO_PUBLIC_SUPABASE_URL=your-supabase-url
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-supabase-anon-key
```

4. **Start the development server:**
```bash
npx expo start
```

5. **Run on device/simulator:**
- Press `i` for iOS simulator
- Press `a` for Android emulator
- Scan QR code with Expo Go app on physical device

## Project Structure

```
autopilot-mobile/
├── app/                          # Expo Router file-based routing
│   ├── (auth)/                   # Auth group (login, register, forgot-password)
│   │   ├── _layout.tsx
│   │   ├── login.tsx
│   │   ├── register.tsx
│   │   └── forgot-password.tsx
│   ├── (app)/                    # Main app group (authenticated)
│   │   ├── _layout.tsx
│   │   ├── (tabs)/               # Tab navigation
│   │   │   ├── _layout.tsx
│   │   │   ├── dashboard.tsx
│   │   │   ├── tickets.tsx
│   │   │   ├── visitors.tsx
│   │   │   ├── inventory.tsx
│   │   │   └── more.tsx
│   │   └── [screens]/            # Detail screens
│   └── index.tsx                 # Entry point
├── src/
│   ├── components/               # Reusable UI components
│   ├── hooks/                    # Custom React hooks
│   │   ├── useAuth.ts
│   │   ├── useData.ts
│   │   ├── useNotifications.ts
│   │   └── ...
│   ├── services/                 # API and external services
│   │   └── supabase.ts
│   ├── store/                    # Zustand state management
│   │   ├── authStore.ts
│   │   ├── themeStore.ts
│   │   └── notificationStore.ts
│   ├── types/                    # TypeScript type definitions
│   │   └── index.ts
│   ├── utils/                    # Utility functions
│   │   └── helpers.ts
│   └── constants/                # App constants
│       └── index.ts
├── assets/                       # Images, fonts, sounds
├── tamagui.config.ts             # Tamagui configuration
├── app.json                      # Expo configuration
├── eas.json                      # EAS Build configuration
└── package.json
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `EXPO_PUBLIC_SUPABASE_URL` | Your Supabase project URL |
| `EXPO_PUBLIC_SUPABASE_ANON_KEY` | Your Supabase anonymous key |
| `EXPO_PUBLIC_GROQ_API_KEY` | Groq API key for AI features |
| `EXPO_PUBLIC_APP_NAME` | App display name |
| `EXPO_PUBLIC_ENABLE_BIOMETRIC_AUTH` | Enable Face ID/Touch ID |
| `EXPO_PUBLIC_ENABLE_PUSH_NOTIFICATIONS` | Enable push notifications |
| `EXPO_PUBLIC_ENABLE_OFFLINE_MODE` | Enable offline support |

## Building for Production

### 1. Configure EAS

Update `eas.json` with your project details:

```json
{
  "build": {
    "production": {
      "channel": "production",
      "env": {
        "APP_VARIANT": "production"
      }
    }
  }
}
```

### 2. Create EAS Project

```bash
eas login
eas init
```

### 3. Build for iOS

```bash
eas build --platform ios --profile production
```

### 4. Build for Android

```bash
eas build --platform android --profile production
```

### 5. Submit to App Stores

```bash
# iOS - App Store
eas submit --platform ios --profile production

# Android - Play Store
eas submit --platform android --profile production
```

## App Store Requirements

### Apple App Store

1. **Developer Account**: $99/year
2. **App Icon**: 1024×1024px
3. **Screenshots**: iPhone 6.7", 6.5", 5.5" + iPad
4. **Privacy Policy**: Required
5. **App Review**: Follow [Guidelines](https://developer.apple.com/app-store/review/guidelines/)

### Google Play Store

1. **Developer Account**: $25 one-time
2. **App Icon**: 512×512px + adaptive icon
3. **Screenshots**: Phone + 7" + 10" tablets
4. **Feature Graphic**: 1024×500px
5. **Privacy Policy**: Required
6. **Data Safety Form**: Required

## Key Features Implementation

### Authentication
- Email/password with Supabase Auth
- Biometric authentication (Face ID/Touch ID/Fingerprint)
- Secure token storage with expo-secure-store
- Automatic token refresh

### Data Fetching
- TanStack Query for server state management
- Infinite scrolling for lists
- Optimistic updates
- Background refetching

### Push Notifications
- Expo Notifications for cross-platform support
- Backend integration with Supabase
- Deep linking from notifications
- Notification categories (tickets, visitors, system)

### Offline Support
- Action queue for offline mutations
- Automatic sync when online
- Optimistic UI updates
- Cache persistence

### Theming
- Light/Dark/System theme support
- Tamagui for consistent styling
- Dynamic theme switching

## Customization

### Adding New Screens

1. Create file in `app/(app)/` directory
2. Follow Expo Router naming conventions
3. Use Tamagui components for UI

### Adding New API Endpoints

1. Add function in `src/services/supabase.ts`
2. Create hook in `src/hooks/useData.ts`
3. Use TanStack Query for data fetching

### Adding New Components

1. Create component in `src/components/`
2. Use Tamagui design tokens
3. Export from index file

## Troubleshooting

### Common Issues

**Metro bundler errors:**
```bash
npx expo start --clear
```

**iOS build fails:**
- Ensure Xcode is up to date
- Run `cd ios && pod install` (if ejected)

**Android build fails:**
- Ensure Android SDK is installed
- Check `ANDROID_HOME` environment variable

**Supabase connection issues:**
- Verify environment variables
- Check Supabase project status
- Ensure RLS policies are configured

### Debug Mode

```bash
# Enable debug logging
DEBUG=* npx expo start

# iOS simulator logs
npx expo logs --ios

# Android emulator logs
npx expo logs --android
```

## Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature/my-feature`
3. Commit changes: `git commit -am 'Add new feature'`
4. Push to branch: `git push origin feature/my-feature`
5. Submit pull request

## License

Private - Autopilot Offices

## Support

For support, contact the development team or create an issue in the repository.

---

**Happy coding! 🚀**
